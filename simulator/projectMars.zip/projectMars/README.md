# 火星文明仿真系统

依据 [plan_finalver.md](plan_finalver.md) 实现的宏观动力系统实验室。包含资源、人口年龄/性别、科技、居住扩张、地火运输、金融账目和社会凝聚力；不依赖第三方Python包或前端网络库。

## 直接使用

在本目录打开终端（Python 3.10+）：

```powershell
python run.py serve
```

浏览器访问 http://127.0.0.1:8765 。左侧可直接输入不设上限的仿真年数，并在 1/12、1/24、1/48 地球年三种时间步长之间选择；两条曲线使用相同观察期和步长比较当前结果与默认参数基准。“任意变量曲线”页支持用中文名称、别名或含义搜索全部数值型时序变量，并显示全过程曲线、初末值和极值。“参数字典”页可按中文名称、含义或代码检索79项参数，校验范围后把覆盖值持久化到 `outputs/用户参数设置.json`，也可单项或一键恢复默认值。页面还可播放时间、查看报告，并导出 JSON、CSV 和变量中文对照表 Excel。服务只监听本机，Ctrl+C停止。

无需启动服务也可以打开 `web/index.html` 查看预生成的16个情景；离线模式不执行自定义求解。若端口被占用，使用 `python run.py serve --port 8766`。

## 复现实验

```powershell
python run.py test
python run.py parameters
python run.py experiments
python run.py simulate --scenario dust --years 40 --steps 24 --out outputs/my_dust.json
python run.py simulate --scenario compound --params examples/policy.json --out outputs/my_policy.json
```

完整实验包含14类事件、1个无事件基准、1个复合情景，10组政策对照，64组配对不确定性抽样（128次求解），以及3种情景×3种步长。默认随机种子固定为20261005，仿真本身为确定性期望值模型。

`python run.py experiments --years 60 --samples 128` 可改变批量实验的观察期和采样数并重建报告；会覆盖 `outputs/` 下同名生成文件。单次仿真的年数没有人为上限，只要求是不小于1的有限数；时间步长允许每地球年12/24/48步。`run.py` 兼容默认不加入当前目录的嵌入式Python发行版。

## 交付内容

- `web/index.html`：中文观测台，情景对照、时间播放、政策运行、数据导出。
- `mars_civilization/`：仿真引擎、参数、事件、批量实验、报告生成和本地接口。
- `docs/model.md`：状态变量、控制方程、量纲、数值推进、金融账目和需求映射。
- `outputs/实验报告.html` / `.md`：基于真实执行结果的实验分析，附资料、适用边界和改进意见。
- `outputs/参数字典.md` / `parameters.json`：所有可调参数的默认值、单位和现象解释。
- `outputs/variables.json`：全部仿真输出变量的中文名称、单位、类别、含义和搜索别名。
- `outputs/01a10adc-f58c-79d2-a85f-6ad280864ee2/变量中文名称与实际意义对照表.xlsx`：77 个输出字段的中文对照表，其中 75 个数值时序变量可直接在前端绘图。
- `docs/参数列表与调参指南.md`：按六个子系统整理的完整参数表，逐项说明上调/下调方式和允许范围。
- `outputs/*.json` / `*.csv`：完整情景时序、守恒审计、在途队列、政策、敏感性与步长比较。
- `outputs/manifest.json`：运行配置、随机种子、主代码SHA-256和主情景审计。
- `tests/test_model.py`：守恒、延迟、事件、出口门槛和数值边界测试。
- `mars_production_v01/`：既有产业链底表，未修改；宏观模型暂未将它当成已闭合工程BOM。

## 如何理解结果

所有时间为地球年；物资为吨当量；MC是虚构记账单位。`rows`第一行为初值，其后为步末存量和当步年化流量；`dt`为实际年步长。`food_import`、`material_import`、`construction_material`和损耗字段为**当步数量**。初值没有产量字段。终点到港/投产项目留在`boundary`队列。

该系统用于比较机制、暴露瓶颈和组织政策讨论。绝大多数社会、生产和金融系数为探索性假设，没有用真实殖民地数据校准；报告明确说明库存过剩、公共配给、金融市场简化等局限，不能直接解释为殖民地预测或投资收益测算。
