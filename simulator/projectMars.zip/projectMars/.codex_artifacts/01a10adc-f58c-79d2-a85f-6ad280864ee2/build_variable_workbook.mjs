import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = "E:/溪山/projectMars";
const outputDir = path.join(root, "outputs", "01a10adc-f58c-79d2-a85f-6ad280864ee2");
const outputPath = path.join(outputDir, "变量中文名称与实际意义对照表.xlsx");
const previewPath = path.join(outputDir, "变量中文名称与实际意义对照表_preview.png");
const source = JSON.parse(await fs.readFile(path.join(root, "outputs", "variables.json"), "utf8"));

const rows = Object.entries(source).map(([key, item], index) => [
  index + 1,
  item.name,
  key,
  item.category,
  item.kind,
  item.unit,
  item.meaning,
  (item.aliases || []).join("、"),
  item.chartable ? "是" : "否",
]);

const workbook = Workbook.create();
const sheet = workbook.worksheets.add("变量对照表");
sheet.showGridLines = false;
sheet.tabColor = "#243C3D";

sheet.getRange("A2:I2").format.rowHeight = 25;
sheet.getRange("A2").values = [["火星文明仿真系统 · 全部变量中文名称与实际意义对照表"]];
sheet.getRange("A2:I2").format.font = { name: "Arial", size: 15, bold: true, color: "#1F2D2D" };
sheet.getRange("A3").values = [[`共 ${rows.length} 个时序输出字段；“可绘图=是”的变量可在前端“任意变量曲线”中按中文名称检索。`]];
sheet.getRange("A3:I3").format.font = { name: "Arial", size: 10, italic: true, color: "#617271" };
sheet.getRange("A3:I3").format.borders = { bottom: { style: "thin", color: "#C7D0CD" } };

const headers = [["序号", "中文名称", "代码字段", "类别", "变量类型", "单位", "实际意义", "中文搜索别名", "可绘图"]];
sheet.getRange("A5:I5").values = headers;
sheet.getRange("A6").write(rows);
const lastRow = 5 + rows.length;
const fullRange = sheet.getRange(`A5:I${lastRow}`);
fullRange.format.font = { name: "Arial", size: 10, color: "#243434" };
fullRange.format.verticalAlignment = "center";
sheet.getRange("A5:I5").format = {
  fill: "#263E3F",
  font: { name: "Arial", size: 10, bold: true, color: "#FFFFFF" },
  horizontalAlignment: "center",
  verticalAlignment: "center",
  rowHeight: 27,
  borders: { insideVertical: { style: "thin", color: "#FFFFFF" }, bottom: { style: "medium", color: "#D78358" } },
};
sheet.getRange(`A6:A${lastRow}`).format.horizontalAlignment = "right";
sheet.getRange(`I6:I${lastRow}`).format.horizontalAlignment = "center";
sheet.getRange(`B6:B${lastRow}`).format.font = { name: "Arial", size: 10, bold: true, color: "#9B5539" };
sheet.getRange(`G6:H${lastRow}`).format.wrapText = true;
sheet.getRange(`A6:I${lastRow}`).format.rowHeight = 33;
sheet.getRange(`A6:I${lastRow}`).format.borders = { insideHorizontal: { style: "thin", color: "#E1E7E4" } };
sheet.getRange(`I6:I${lastRow}`).conditionalFormats.add("containsText", {
  text: "否",
  format: { fill: "#F5E5D8", font: { color: "#9B5539", bold: true } },
});

const widths = [8, 24, 25, 18, 16, 18, 72, 36, 10];
for (let i = 0; i < widths.length; i += 1) {
  sheet.getRangeByIndexes(0, i, lastRow, 1).format.columnWidth = widths[i];
}
sheet.freezePanes.freezeRows(5);
const table = sheet.tables.add(`A5:I${lastRow}`, true, "VariableDictionary");
table.style = "TableStyleMedium2";
table.showBandedColumns = false;
table.showFilterButton = true;

workbook.recalculate();
await fs.mkdir(outputDir, { recursive: true });
const preview = await workbook.render({ sheetName: "变量对照表", range: "A1:I20", scale: 1, format: "png" });
await fs.writeFile(previewPath, new Uint8Array(await preview.arrayBuffer()));
const exported = await SpreadsheetFile.exportXlsx(workbook);
await exported.save(outputPath);

const imported = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));
const inspection = await imported.inspect({
  kind: "region,table",
  sheetId: "变量对照表",
  range: `A1:I${Math.min(lastRow, 12)}`,
  maxChars: 5000,
  tableMaxRows: 12,
  tableMaxCols: 9,
});
console.log(JSON.stringify({ outputPath, previewPath, rows: rows.length, inspection: inspection.ndjson }, null, 2));
