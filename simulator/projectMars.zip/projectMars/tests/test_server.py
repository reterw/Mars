import http.client
import json
import threading
import tempfile
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from mars_civilization.server import Handler


class APItests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.thread.join()

    def request(self,body,path='/api/simulate',method='POST'):
        c=http.client.HTTPConnection('127.0.0.1',self.server.server_port)
        c.request(method,path,None if body is None else json.dumps(body),{'Content-Type':'application/json'})
        r=c.getresponse(); status=r.status; data=json.loads(r.read()); c.close()
        return status,data

    def test_custom_solve(self):
        status,r=self.request({'years':2,'steps_per_year':24,'scenario':'baseline','overrides':{'research_share':.05}})
        self.assertEqual(status,200)
        self.assertEqual(r['parameters']['research_share'],.05)
        self.assertAlmostEqual(r['rows'][-1]['year'],2)
        self.assertEqual(r['steps_per_year'],24)
        self.assertLess(r['audit']['finance'],1e-7)

    def test_parameter_settings_persist_and_reset(self):
        with tempfile.TemporaryDirectory() as directory, patch('mars_civilization.server.PARAMETER_SETTINGS',Path(directory)/'settings.json'):
            status,r=self.request({'overrides':{'research_share':.05,'food_yield':1.2}},'/api/parameters')
            self.assertEqual(status,200)
            self.assertEqual(r['overrides']['food_yield'],1.2)
            status,r=self.request(None,'/api/parameters','GET')
            self.assertEqual(status,200)
            self.assertEqual(r['overrides']['research_share'],.05)
            status,r=self.request({'overrides':{}},'/api/parameters')
            self.assertEqual(status,200)
            self.assertEqual(r['overrides'],{})

    def test_parameter_settings_reject_invalid_values(self):
        with tempfile.TemporaryDirectory() as directory, patch('mars_civilization.server.PARAMETER_SETTINGS',Path(directory)/'settings.json'):
            for overrides in ({'bad':1},{'research_share':1},[]):
                status,r=self.request({'overrides':overrides},'/api/parameters')
                self.assertEqual(status,400)
                self.assertIn('error',r)

    def test_invalid_request(self):
        for body in ({'years':0},{'overrides':[]},{'overrides':{'bad':1}},{'scenario':{}},{'unknown':1},[],{'steps_per_year':13}):
            with self.subTest(body=body):
                status,r=self.request(body)
                self.assertEqual(status,400)
                self.assertIn('error',r)
