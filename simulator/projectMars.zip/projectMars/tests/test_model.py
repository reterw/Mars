import math
import unittest
from unittest.mock import patch
from mars_civilization.model import simulate, initial_state, effective
from mars_civilization.parameters import defaults
from mars_civilization.events import EVENTS
from mars_civilization.parameter_guide import GROUPS, TUNING, validate_coverage
from mars_civilization.parameters import PARAMETERS
from mars_civilization.variables import VARIABLES, validate_row_keys


class ModelTests(unittest.TestCase):
    def test_parameter_guide_covers_every_parameter(self):
        validate_coverage()
        grouped = [key for keys in GROUPS.values() for key in keys]
        self.assertEqual(set(grouped), set(PARAMETERS))
        self.assertEqual(set(TUNING), set(PARAMETERS))

    def test_variable_catalogue_covers_every_timeseries_field(self):
        result = simulate(years=1)
        keys = set().union(*(row.keys() for row in result['rows']))
        validate_row_keys(keys)
        self.assertEqual(set(VARIABLES), keys)
        self.assertTrue(all(v.name and v.meaning and v.unit for v in VARIABLES.values()))

    def test_every_scenario_balances(self):
        for name in ['baseline','compound']+[e['id'] for e in EVENTS]:
            with self.subTest(scenario=name):
                result=simulate(scenario=name)
                for key in ('food','material','population','finance'):
                    self.assertLess(result['audit'][key],1e-7)
                self.assertGreaterEqual(result['audit']['minimum_stock'],-1e-9)
                for r in result['rows'][1:]:
                    self.assertLessEqual(r['energy_used'],r['power']+1e-8)

    def test_birth_death_migration_identity(self):
        r=simulate()['rows'][-1]
        self.assertAlmostEqual(r['population'],5000+r['cumulative_births']-r['cumulative_deaths']+r['cumulative_arrivals']-r['cumulative_departures'],places=7)

    def test_identical_pre_event_and_changed_after(self):
        b=simulate(years=14)
        r=simulate(years=14,scenario='epidemic')
        self.assertEqual(b['rows'][:121],r['rows'][:121])
        self.assertLess(r['summary']['population'],b['summary']['population'])

    def test_event_expires_without_erasing_state(self):
        p=defaults(); e=next(e for e in EVENTS if e['id']=='epidemic')
        self.assertEqual(effective(p,[e],9.99)[0]['epidemic'],0)
        self.assertAlmostEqual(effective(p,[e],10)[0]['epidemic'],.025)
        self.assertEqual(effective(p,[e],12)[0]['epidemic'],0)

    def test_transport_delays_and_window(self):
        r=simulate(years=4)
        launches=[x for x in r['log'] if x['kind']=='launch']
        arrivals=[x for x in r['log'] if x['kind']=='arrival']
        self.assertAlmostEqual(launches[1]['year']-launches[0]['year'],26/12)
        self.assertAlmostEqual(arrivals[0]['year'],7/12)
        self.assertTrue(all(x['cumulative_arrivals']==0 for x in r['rows'] if x['year']<=7/12+1e-8))

    def test_embargo_blocks_launches_not_inflight(self):
        r=simulate(years=18,scenario='embargo')
        blocked=[x for x in r['log'] if x['kind']=='launch' and 10<=x['year']<16]
        self.assertTrue(blocked)
        self.assertTrue(all(x['cargo']==0 and x['immigrants']==0 for x in blocked))
        self.assertGreater(sum(x['cargo'] for x in r['log'] if x['kind']=='launch' and x['year']>=16),0)
        event=next(e.copy() for e in EVENTS if e['id']=='embargo')
        event['start']=.25
        with patch('mars_civilization.model.scenario_events',return_value=[event]):
            transit=simulate(years=2)
        self.assertGreater(transit['summary']['arrivals'],0)
        self.assertAlmostEqual(next(x['year'] for x in transit['log'] if x['kind']=='arrival'),7/12)

    def test_export_gate_and_delayed_payment(self):
        r=simulate(years=2)
        self.assertEqual(r['summary']['exports'],0)
        s=initial_state(); s['tech']=[2.]*4; s['pop']=[x*1.4 for x in s['pop']]; s['homes']=10000
        r=simulate(years=2,state=s)
        first=r['log'][0]
        self.assertGreater(first['exported'],0)
        self.assertEqual(r['rows'][1]['cumulative_exports'],0)
        self.assertGreater(r['summary']['exports'],0)
        self.assertAlmostEqual(r['summary']['exports'],first['exported']*.97)

    def test_building_delay(self):
        r=simulate(years=2)
        p=defaults(); initial=initial_state()
        # Before commissioning, capacity may only decay.
        for x in r['rows']:
            if x['year']<=1+1e-8:
                self.assertAlmostEqual(x['homes'],initial['homes']*math.exp(-p['depreciation']*x['year']),places=6)

    def test_empty_colony_no_spontaneous_population(self):
        s=initial_state(); s['pop']=[0.]*6
        r=simulate(years=2,state=s,overrides={'migration':0})
        self.assertEqual(r['summary']['population'],0)
        self.assertTrue(all(x['power']==0 for x in r['rows'][1:]))

    def test_zero_supply_causes_shortage_but_nonnegative(self):
        s=initial_state(); s.update(food=0,food_cap=0,energy_cap=0,material=0)
        r=simulate(years=2,state=s,overrides={'cargo_capacity':0,'migration':0,'earth_grant':0})
        self.assertGreater(r['summary']['shortage_years'],1)
        self.assertLess(r['summary']['population'],5000)
        self.assertGreaterEqual(r['audit']['minimum_stock'],0)

    def test_reproducible(self):
        self.assertEqual(simulate(years=2),simulate(years=2))

    def test_sex_ratio_constrains_natural_births(self):
        s=initial_state(); s['pop']=[900.,0.,1500.,0.,100.,0.]
        r=simulate(years=2,state=s,overrides={'migration':0})
        self.assertEqual(r['summary']['births'],0)

    def test_invalid_inputs(self):
        for kw in ({'years':float('nan')},{'years':0},{'steps_per_year':1},{'overrides':{'food_need':-1}},
                   {'overrides':{'what':1}},{'overrides':{'availability':float('inf')}},{'scenario':'unknown'}):
            with self.subTest(kw=kw),self.assertRaises(ValueError): simulate(**kw)

    def test_horizon_has_no_artificial_upper_limit(self):
        r=simulate(years=101)
        self.assertAlmostEqual(r['rows'][-1]['year'],101)
        self.assertEqual(r['years'],101)

    def test_step_convergence(self):
        for scenario in ('baseline','compound'):
            a=simulate(scenario=scenario)['summary']; b=simulate(scenario=scenario,steps_per_year=48)['summary']
            self.assertLess(abs(a['population']/b['population']-1),.03)
            self.assertLess(abs(a['gdp_real']/b['gdp_real']-1),.03)


if __name__=='__main__': unittest.main()
