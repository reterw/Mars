# 火星文明宏观动力系统：变量、方程与参数

本模型按 `plan_finalver.md` 的顺序设计：先确定存量变量，再列流量与控制方程，由方程识别参数，最后执行事件、政策及不确定性实验。实现位于 `mars_civilization/model.py`，所有可调系数集中在 `parameters.py`，逐项中文参数表自动导出为 `outputs/参数字典.md` 与 `parameters.json`。

## 1. 仿真尺度与建模取舍

对象为单一聚合火星城市及其周边生产、采集与物流设施。时间为**地球年**，默认步长 h=1/12 年；求解器也支持 h=1/24 年和 h=1/48 年，并可在前端调参面板选择。`steps_per_year` 是数值求解配置，不是描述现实机制的 `parameters.py` 参数。遇到到港、投产、事件边界或发射窗口时，程序会把当前步进一步切短，因此所选值是常规最大步长。功率单位MW，资源单位t，货币单位百万MC。每年按365.25×24=8766小时转换；地火窗口26个月和七个月航行是特定轨道方案的近似。这里研究几十年的社会演化，不模拟小时级温控、电网或个人决策。

采用确定性存量—流量混合时滞模型。出生、死亡、迁徙与交付可以是非整数期望值。容量、库存、预算非负；银行股本允许负值，以显式表示资不抵债。没有把能源当作可累计物资，未建储能系统。

**资源口径**：B为可食用干生物质当量，非全部生物有机物湿重；R为标准化生产原料当量，包含采集与工业加工的合并净产出。R并非元素质量守恒模型，B来自未显式展开的水、CO₂和养分环境通量。这里的守恒只指每类聚合库存账目闭合，不能证明完整物理质量闭合。

## 2. 核心变量

|类别|变量 / 代码字段|单位|实际意义|
|---|---|---|---|
|资源|B / food|t|食物库存|
|资源|R / material|t|可用于维护、建设和出口的原料库存|
|能源|P / power|MW|当步可用发电功率，代数流量，不跨期储存|
|人口|N_cf,N_cm,N_af,N_am,N_of,N_om / pop|人|少年、成年、老年，女性和男性六队列|
|人口|female_fraction|1|全体女性比例；成年女性数用于生育方程|
|人口|children,adults,elderly|人|抚养负担、劳动供给和老龄化|
|设施|K_E / energy_cap|MW|能源设施名义容量|
|设施|K_A / food_cap|t/年|农业基准年产能|
|设施|K_I / mine_cap|t/年|工业/采集基准年产能|
|设施|H / homes|人|加压防护居住容量|
|设施|K_T / transport_cap|t·km/年|火星内部运输能力|
|科技|T_E,T_A,T_I,T_H / tech|1|能源、农业、工业与健康能力相对指数|
|社会|C / cohesion|1|0—1的合作与制度信任代理量，不是综合福利分数|
|物价|p / price|1|单一商品篮子价格指数|
|货币|D_h,D_f,D_g / household,firms,treasury|百万MC|居民、企业、财政在同一银行的存款|
|信用|L,G / loans,bonds|百万MC|银行持有的企业贷款和公共债券|
|对外|F / reserves|百万MC|单一结算货币外部流动资产，假设固定平价|
|金融|E_b / equity|百万MC|银行股本，可为负|
|队列|ships|t、人、年、百万MC|发射时确认的货物/人员、到港时间与出口应收现金|
|队列|projects|对应产能、年|在建项目及投产时间|
|记录|cumulative_*|t、人或百万MC|累计出生、死亡、迁移、交付、出口和核销|

产值 Y 为**固定基年价格的增加值代理量**，不是完整国民账户。农业和原料的产出价值加居民生命用电价值，再扣维护材料；生产内部耗电不重复计入。未售出的产出仍体现为库存增加，模型不含库存估值损失。

## 3. 参数约定

下文使用的参数名均对应 `parameters.py` 中的键。参数目录列出默认值、单位、输入范围、实际意义、现象如何改变参数、证据等级。O代表近似观测约束，A代表参照任务案例，H代表探索性假设；除窗口与航行时间外，大多数参数为H。输入范围是允许的情景扫描范围，不是统计置信区间。

`min` 是硬资源约束，`[x]+ = max(0,x)`，`clip(x,0,1)` 为比例限幅。h为实际步长，Y为年化产值，N为人口，N_a为成年人口。下列公式按代码执行顺序解释，不能当成同时求解的无约束方程。

## 4. 生产：劳动力、电力、物流联合约束

有效劳动力：

```
W = N_a × participation × (0.5 + 0.5 C)
W_science = W × research_share
W_available = W - W_science
W_required = K_E labor_per_mw + K_A labor_per_food
           + K_I labor_per_material + K_T labor_per_transport
u_L = min(1, W_available / W_required)
W_build = max(0, W_available - u_L W_required)
```

生产部门同比分配短缺劳动力，维护人工包含在部门系数中；建设只能使用剩余劳动力。科研支出比例同时代理科研人员配置，这一合并关系以后应拆分为教育和人才市场。

```
P = K_E × availability × T_E × u_L
P_life = N × life_power / sqrt(T_H)
u_E = min(1, P/P_life)
Q_remaining = max(0, P-P_life) × 8766
A* = K_A × food_yield × T_A × u_L
I* = K_I × mining_yield × T_I × u_L
V = K_T × sqrt(T_I) × u_L
u_T = min(1, V / [(A*+I*) × distance])
e_A = agri_energy/sqrt(T_A) + distance × transport_energy
e_I = mine_energy/sqrt(T_I) + distance × transport_energy
u_Q = min(1, Q_remaining / [u_T A* e_A + u_T I* e_I])
A = u_Q × u_T × A*
I = u_Q × u_T × I*
Q_build = Q_remaining - A e_A - I e_I
```

能源首先保生命保障，再按比例供应两类生产，余量可用于建设；不存在同一电力被多次花费。火星内部物流通过t·km/年的吞吐上限和吨公里能耗约束实现，暂不分城市网络，也不单列库内装卸。

## 5. 存量变化和维护

先接收入港货物，再当步生产，再储存损耗和消费，最后维护、建设和出口（出口实际发生于步初发射时）。守恒式统一为：

```
B_next = B + B_import + A h - B_loss - B_consumed
B_loss = (B + B_import + A h) × [1-exp(-food_loss h)]
B_consumed = min(B_before_consumption, N food_need h)
u_F = B_consumed / (N food_need h)
R_next = R + R_import + I h - R_loss - R_maintenance - R_build - R_export
M_K = Σ capacity_j × material_per_capacity_j
R_maintenance = min(R_available, M_K maintenance h)
u_M = R_maintenance / (M_K maintenance h)
```

R_loss也采用指数库存损耗，但步初已发射的出口货物不再计入火星库存。损耗转入系统边界外；未把废料回收凭空作为新资源。

## 6. 地火运输、贸易和迁徙

发射时刻 `t_k = k × window`。进口移民需求是 `min(passenger_capacity, migration × window × C, max(0,H-N))`。进口货物预定量是cargo_capacity，按import_food_fraction分配给生物质；其余为原料。模型当前按运力规划进口，不做按库存需求优化，可能积累过大库存。

```
Cost = cargo × import_price + passengers × passenger_price
f = min(1, D_g/Cost, F/Cost)
支付Cost×f；冻结本次manifest
到港时间 = 发射时间 + flight
实际交付 = 计划装载 × f × delivery_success
```

发射后，事件不改变已在途manifest。交付损失不重新抽样，均按期望成功比例表示；初始没有在途货物。移民女性比例在发射时确定，均进入成年队列。到港时不再按住房拒绝已搭乘人员，因此途中住房损毁可能造成拥挤。

返航意愿 `N × emigration × window × (1-C)`，受单独的客运上限、居民可付存款和对外储备约束。离开火星时按各年龄性别人口比例扣减；不跟踪其在地球的人口结果。双向客运分别限制，暂无共享火箭调度。

反哺地球必须同时满足：`min(T_E,T_A,T_I) ≥ export_tech`、`N ≥ export_population`、上一时步食物满足率为1、食物库存达到reserve_food_years目标。出口量受export_capacity、扣除维护缓冲后的可用原料、企业及外汇可付运费约束。发射时扣减火星原料并支付运费，航程结束后按成功交付比例确认收入及实际交付出口量；期末未抵达部分保留队列。该产品篮子代表高价值货物原料当量，不代表普通矿石存在盈利贸易。

## 7. 人口繁衍、死亡和年龄结构

女性比例由出生、存量年龄迁移和实际移民决定，不以性比优化政策福利。有效成年女性生育率已含生育年龄份额：

```
Births = min(N_af,N_am) × fertility × C × u_F × u_E × min(1,H/N) × h
crowding = max(0,N/H-1)
stress = (1-u_F)+(1-u_E)
μ_j = [death_j + epidemic + shortage_mortality×stress
       + crowding_mortality×crowding] / sqrt(T_H)
γ_child=1/child_years; γ_adult=1/adult_years; γ_old=0
Out_j = N_j × [1-exp(-(μ_j+γ_j)h)]
Deaths_j = Out_j × μ_j/(μ_j+γ_j)
Aging_j = Out_j - Deaths_j
```

年龄迁移按性别保留，新生儿按female_birth分配。min(N_af,N_am)为可配对生育规模的保守代理，不推断个人关系或婚姻制度；没有模拟辅助生殖或生殖材料库存，任一成年性别为零时自然出生为零。采用竞争风险避免同一人同时死亡和年龄迁移以及负队列。指数阶段并不精确代表18岁生日，允许较早流入成年；在缺乏数据时为可解释近似，不能用于临床或代际繁殖可行性判断。

```
N_next = N + Births - Deaths + Arrivals - Departures
C_next = clip(C + h[cohesion_speed(cohesion_target-C)
                    - cohesion_stress×stress - 0.03×crowding],0,1)
```

0.5+0.5C劳动调节、0.03/年拥挤压力是固定结构系数，属于H；后续应当纳入结构敏感性，而不是视为经验定律。

## 8. 文明扩张

按能源、食物、原料、住房和物流五种目标形成缺口；已下单待投产容量从缺口扣除，避免重复下单：

```
E_target = 1.5 × [P_life + (N food_need e_A + max(5000,N×2) e_I)/8766]
           / max(availability T_E,0.05)
A_target = 1.6 × N food_need / max(food_yield T_A,0.05)
I_target = max(5000,N×2) / max(mining_yield T_I,0.05)
H_target = 1.35 × N
V_target = 1.35 × (u_T A* + u_T I*) × distance / sqrt(T_I)
G_j = max(0,target_j-capacity_j-pipeline_j) × material_per_capacity_j
Build = min(ΣG_j, 可用原料-维护缓冲, Q_build h/build_energy,
            W_build h/build_labor, D_g/(build_price p),
            Y p investment_share h/(build_price p))
Δcapacity_j = Build × (G_j/ΣG_j) / material_per_capacity_j
```

目标倍数1.5、1.6、1.35是固定结构性安全余量；5000 t/年为产业底座目标，2 t/(人·年)为人均原料需求目标，均为H而非火星工程数据。每步建设成本立即支付、消耗材料与能源，`t+h+build_delay` 时一次性投产。这里每个“项目”是数值投资批次，界面项目数量不等于真实建筑物数量。

```
capacity_next = capacity × exp[-(depreciation + unmaintained_decay×(1-u_M))h]
```

投产前不产生能力，已建设材料不会因项目还未完工继续留在库存。在建项目无故障、融资成本与建设期间材料损失，未来应细化。扩张是产能与居住能力增长，不等于已实现多城市空间扩张。

## 9. 科技发展

公共科研预算 `Y p research_share h` 由实际财政存款限额支付，发到科研人员存款。每个科技指数按同一基准演化律：

```
funding = annual_research / (research_scale + annual_research)
scientist = min(1, W_science/(0.02 N))
g = research_productivity × funding × scientist × C × u_E × u_F
T_j,next = max(0.3, T_j × exp([g(1-T_j/tech_ceiling)-knowledge_decay]h))
```

0.02是充分科研人员配置的人口比例，0.3是知识能力指数下界，均为结构假设。当前四种科技共享研究律且初值相同，基准中同步演化；保留不同索引是为了作用于不同生产/健康方程，不能把四条相同曲线解释成四个独立已验证技术进程。下一版应分科研预算、人才与扩散网络。

## 10. 金融体系与贸易记账

单一银行的核心恒等式在每一步检查：

```
企业贷款L + 公共债券G + 外部储备F = 居民存款D_h + 企业存款D_f + 财政存款D_g + 银行股本E_b
货币存量M = D_h + D_f + D_g
```

|行为|资产变化|存款/权益变化|
|---|---|---|
|发放企业贷款l|L+=l|D_f+=l，贷款创造货币|
|偿还企业本金a|L-=a|D_f-=a，销毁存款|
|公共发债g|G+=g|D_g+=g，银行认购并创造财政存款|
|企业违约d|L-=d|E_b-=d，贷款损失由银行股本承担|
|支付贷款或债券利息i|资产不变|借款者存款-=i，E_b+=i|
|地球财政拨款g|F+=g|D_g+=g|
|进口与客运支付c|F-=c|付款者存款-=c|
|出口到达后的外部支付x|F+=x|D_f+=x|
|工资、税收、消费、研发、建设|银行总资产不变|在国内账户之间转账，总存款不变|

新增企业授信只用于工资流动资金缺口，受资本空间 `max(0,E_b/capital_ratio-L-G)` 限制。居民工资为产值×wage_share，资金不足实际少付；工资和销售分别征tax_rate税，两者税基不同。居民消费支付 `min(Yp h,D_h money_velocity h)`；生活资源采用公共配给，当前未把个体支付能力作为生存配给门槛。

坏账率 `default_rate + 0.08(1-u_F) + 0.05(1-u_E)`，年率系数0.08、0.05为H。按指数核销贷款，银行股本可为负；资不抵债后无新增信用，但存款支付继续进行，尚未建清算/挤兑处置。未付利息当期豁免，未计应计欠息；公共债务不设主动还本，都是必须在投资讨论中说明的简化。

公共建设与科研预算不能由原料库存直接换成钱。资金不足时允许发债，但同时受债务/产值上限和银行资本上限限制。债务上限只约束新发行，之后产值或价格下降可能令比率超限，不会偷偷核销超额债务。

```
Y = max(0, A price_food + I price_material
        + min(P,P_life)8766 price_energy - 年维护原料 price_material)
money_pressure = clip(D_h money_velocity/(Yp)-1,-0.5,1)
π = inflation_speed × [stress + 0.3 money_pressure]
p_next = p × exp(clip(π,-0.5,1)h)
```

物价方程是经验式假设，0.3货币需求权重和通胀限幅是结构系数。基准中可能长期通缩，使名义债务负担上升、同一名义拨款实际购买力上升，不能误读为真实火星货币趋势。银行利润不分红和债务不摊销同样改变长期分配。

## 11. 数值推进、边界与输出

1. 在步初完成应到达货运和建设投产，取当时有效事件参数。
2. 如遇发射窗口，固定本次运输manifest并完成外部付款、返航与出口装载。
3. 按最近的月步终点、发射、到港、投产和事件开始/结束边界确定h。
4. 计算劳动、电力、内部运输、生产、损耗、消费、维护。
5. 计算产值、外援、授信、工资、消费、税收、利息、还本、坏账与发债。
6. 支付科研、积累科技；按四类实际限制建设、加入在建队列并折旧。
7. 推进人口、凝聚力和物价，检查非负、有限值与四类守恒残差。

时域为[0,T)，正好T时到达的队列不结算，保留在结果boundary中；rows每行是步末状态，人口/货物到港记录在实际接收后第一行，log保存精确时间。首行只有初始存量，不虚构已发生的产出。累计短缺年数用实际h加总，而不是统计行数。

分母极小时用1e-9或1e-12的数值保护，人口为零时无劳动、出生或生产；仍允许地球拨款等外生动作。参数接口拒绝未知键、越界、NaN与无穷值。

## 12. 与既有生产底表的关系

`mars_production_v01/mars_production_v01/` 原样保留。其资源目录、工艺联产与主原料矩阵可作为未来的细粒度工程层，但它明确注明矿藏未知、外部关键投入和未闭合项。当前不将其69条工艺的系数直接加总为R，以免把联产副产品重复计算或把未知矿藏当已开采库存。

建议适配层：用最终需求向量d与工艺约束解非负生产调度，导出年总能耗、劳动、可交付生物质和可替代原料；对关键设备维护与进口零部件设独立不可替代限制。宏观层给出人口、投资和生活需求，工程层返回实际可行产出与约束影子价格。这个连接需要先补齐BOM，不属于已经实现的接口。

## 13. 需求验收映射

|plan_finalver.md 要求|实现与交付|
|---|---|
|宏观、社会历史尺度动力系统|model.py；40年/月步/事件与时滞|
|能源、生物质、原材料|功率流量、两类库存和限额生产/建设|
|人口、性比及补充变量|六年龄性别队列、迁移、劳动、凝聚力|
|科技|四能力指数、财政研发、知识积累与折损|
|货币及金融体系|三部门存款、银行贷款/债券/股本、外汇与闭合账目|
|生产/运输/繁衍/扩张/科研/金融方程|本文件第4—10节，与model.py对应|
|参数意义、单位、现象解释|parameters.py、outputs/参数字典.md及界面参数字典|
|初始/边界条件、10个以上事件|14类独立事件+基准+复合冲击，完整CSV/JSON|
|量化约束与评估|资源上限、事件参数乘数/加数、反事实对照和恢复判据|
|检索资料、真实性、讨论价值、改进|实验报告中7项证据核查、5类讨论维度和优先级建议|
|最终实验报告|outputs/实验报告.md 与 HTML|
|无量纲参数探索|8个Pi候选指标、代码时序输出及报告讨论|

真实社会现象不可能通过几条聚合方程“充分穷尽”。本实现确保各方程所依赖的主要核心变量有明确通道，同时把未涵盖因素逐项公开，避免把形式闭合误认为科学定论。
