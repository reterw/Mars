"""All adjustable model coefficients, their units, and interpretation."""
from dataclasses import dataclass, asdict


@dataclass(frozen=True)
class Parameter:
    value: float
    unit: str
    meaning: str
    interpretation: str
    low: float
    high: float
    evidence: str = "H：探索性假设，未校准"


PARAMETERS = {}


def add(key, value, unit, meaning, interpretation, low, high, evidence=None):
    PARAMETERS[key] = Parameter(value, unit, meaning, interpretation, low, high,
                                evidence or "H：探索性假设，未校准")


add('availability', .85, '1', '能源设施可用率', '检修、故障、沙尘降低；冗余提升', .1, 1)
add('food_yield', 1, '1', '农业产率系数', '丰收、栽培突破提高；病害降低', .1, 2)
add('mining_yield', 1, '1', '原料产率系数', '矿脉品质、开采工艺提高；枯竭降低', .1, 2)
add('food_need', .28, 't/(人·年)', '可食用干生物质需求', '营养需求和浪费提高；这里不是湿重或完整生态质量', .18, .45)
add('life_power', .004, 'MW/人', '生命保障及生活平均功率', '保温失效、循环系统低效提高', .001, .012)
add('agri_energy', 12, 'MWh/t', '农业能耗', '人工照明提高；照明效率提高则降低', 2, 35)
add('mine_energy', 2, 'MWh/t', '原料开采加工能耗', '贫矿和深层采掘提高', .3, 8)
add('transport_energy', .00015, 'MWh/(t·km)', '内部运输能耗', '路线恶化提高；车辆效率提高则降低', .00003, .001)
add('distance', 100, 'km', '平均内部运输距离', '空间扩张提高；紧凑布局降低', 5, 800)
add('food_loss', .08, '1/年', '生物质储存损耗率', '冷链失效提高', 0, .5)
add('material_loss', .005, '1/年', '原料储存损耗率', '防护、循环利用降低', 0, .1)
add('maintenance', .012, '1/年', '按设施材料当量计维护需求', '老化、沙尘磨损提高', .002, .05)
add('depreciation', .018, '1/年', '维护充足时设施折旧率', '耐久性改善降低', .003, .06)
add('unmaintained_decay', .12, '1/年', '缺少维护的附加折旧', '缺件和管理失灵提高', 0, .5)
add('labor_per_mw', 5, '人/MW', '能源运维人员需求', '自动化降低', 1, 20)
add('labor_per_food', .18, '人/(t/年)', '农业人员需求', '自动化降低', .02, .5)
add('labor_per_material', .025, '人/(t/年)', '工业人员需求', '自动化降低', .003, .1)
add('labor_per_transport', .00015, '人/(t·km/年)', '物流人员需求', '自动化降低', .00001, .001)
add('participation', .72, '1', '成年人劳动参与率', '疾病、照护负担降低', .1, .95)
add('fertility', .065, '出生/(成年女性·年)', '有效生育率', '含成年女性生育年龄比例；安全感、育儿政策提高', 0, .16)
add('female_birth', .488, '1', '出生女性比例', '作为生物人口参数；不作为政策优化目标', .4, .6)
add('death_child', .002, '1/年', '少年死亡风险率', '公共卫生恶化提高', 0, .03)
add('death_adult', .004, '1/年', '成年死亡风险率', '辐射、医疗不足提高', 0, .05)
add('death_old', .05, '1/年', '老年死亡风险率', '医疗突破降低', .005, .15)
add('child_years', 18, '年', '少年平均阶段长度', '指数队列近似，不是逐岁年龄队列', 12, 25)
add('adult_years', 47, '年', '成年平均阶段长度', '更长健康工作期提高', 30, 60)
add('shortage_mortality', .35, '1/年', '食物和生命能源短缺附加死亡风险', '应急保障提高则降低', .03, 1)
add('crowding_mortality', .025, '1/年', '超员附加死亡风险', '居住拥挤、传染病传播提高', 0, .1)
add('epidemic', 0, '1/年', '外源疫病/灾害死亡风险', '事件冲击提高', 0, .3)
add('migration', 110, '人/年', '地球移民意愿上限', '地球吸引力下降或火星繁荣提高', 0, 500)
add('migration_female', .5, '1', '成年移民女性比例', '仅描述移民结构', .1, .9)
add('emigration', .008, '1/年', '不满驱动的返航意愿率', '冲突、低信任提高', 0, .1)
add('cohesion_target', .72, '1', '社会凝聚力长期目标', '文化作品、公共服务、制度信任提高', .1, 1)
add('cohesion_speed', .25, '1/年', '社会凝聚力调整速度', '公共沟通和组织能力提高', .05, 1)
add('cohesion_stress', .3, '1/年', '短缺对凝聚力的损伤系数', '不平等、分配失灵提高', 0, 1)
add('research_share', .035, '1', '公共研发支出占名义产值比例', '教育、科研优先级提高', 0, .15)
add('research_productivity', .06, '1/年', '充分投入时科技增长系数', '制度开放、重大理论突破提高', 0, .3)
add('research_scale', .4, '百万MC/年', '研发投入半饱和尺度', '科研成本、设备依赖提高', .05, 3)
add('tech_ceiling', 3, '1', '相对初始水平科技上限', '纯情景参数，不代表物理极限', 1, 6)
add('knowledge_decay', .002, '1/年', '知识/能力流失率', '人才流失、教育崩溃提高', 0, .03)
add('investment_share', .18, '1', '公共建设预算占名义产值比例', '扩张政策提高', 0, .5)
add('material_per_mw', 45, 't/MW', '能源设施建设原料当量', '集成化降低', 10, 150)
add('material_per_food', .5, 't/(t/年)', '农业设施建设原料当量', '温室结构、照明复杂度提高', .1, 2)
add('material_per_mine', .12, 't/(t/年)', '采集/工业设施建设原料当量', '矿业装备复杂度提高', .03, .5)
add('material_per_home', 2, 't/人', '居住容量建设原料当量', '防辐射、防压要求提高', .5, 8)
add('material_per_transport', .001, 't/(t·km/年)', '物流运力建设原料当量', '长距离基础设施成本提高', .0002, .005)
add('build_price', .01, '百万MC/t', '建设材料及施工单价', '供应紧张提高；单一价格指数同步调整', .002, .03)
add('build_energy', 3, 'MWh/t', '建设能耗', '施工困难提高', .5, 10)
add('build_labor', .025, '人·年/t', '建设劳动需求', '自动化降低', .003, .1)
add('build_delay', 1, '年', '建设投产时滞', '复杂项目和审批延误提高', .25, 3)
add('reserve_food_years', 1.5, '年', '食物库存目标', '韧性政策提高', .25, 4)
add('reserve_material_years', .7, '年', '原料维护库存目标', '风险规避提高', .1, 3)
add('window', 26/12, '年', '地火发射窗口间隔', '采用近似固定周期', 26/12, 26/12, 'O：NASA JPL 发射窗口约26个月 [S2]')
add('flight', 7/12, '年', '地火航行时滞', '轨道方案变化；七个月是实例，不是普适常数', 4/12, 12/12, 'A：参照 Perseverance 七个月航程 [S2]')
add('cargo_capacity', 3000, 't/窗口', '地球向火星货运上限', '运载系统、轨道设施改善提高', 0, 12000)
add('passenger_capacity', 350, '人/窗口', '双向分别计的客运上限', '运输基础设施改善提高', 0, 1500)
add('delivery_success', .97, '1', '期望交付成功比例', '着陆、轨道风险提高则降低；确定性期望值', 0, 1)
add('import_food_fraction', .55, '1', '进口货物中生物质份额', '饥荒应急优先级提高', 0, 1)
add('import_price', .002, '百万MC/t', '到岸货物单价', '技术改善降低；虚构记账单位，非真实发射报价', .0002, .02)
add('passenger_price', .008, '百万MC/人', '移民单程费用', '生命保障与运载成本提高', .001, .1)
add('earth_grant', 5, '百万MC/年', '地球财政转移', '合作提高；禁运、预算削减降低', 0, 20)
add('export_tech', 1.5, '1', '出口技术门槛', '高价值可交付产品能力要求', 1, 3)
add('export_population', 6500, '人', '出口规模门槛', '社会分工的最低规模假设', 0, 20000)
add('export_capacity', 1500, 't/窗口', '反哺地球运力上限', '返航基础设施提高', 0, 5000)
add('export_price', .004, '百万MC/t', '地球支付的原料当量净货价', '仅代表高价值产品篮子，非运普通矿石的盈利预测', 0, .03)
add('export_freight', .0008, '百万MC/t', '出口运费', '运载成本提高', 0, .005)
add('tax_rate', .18, '1', '企业销售税与居民工资税率', '公共融资偏好提高', 0, .5)
add('wage_share', .55, '1', '生产收入对应工资份额', '劳动力议价能力提高', .1, .85)
add('loan_rate', .045, '1/年', '企业贷款年利率', '风险溢价、紧缩提高', 0, .25)
add('bond_rate', .025, '1/年', '公共债券年利率', '财政风险提高', 0, .2)
add('loan_amortization', .08, '1/年', '企业贷款计划偿还率', '信用期限缩短提高', 0, .5)
add('default_rate', .005, '1/年', '基准违约核销率', '衰退和冲突提高；由银行股本吸收', 0, .3)
add('capital_ratio', .12, '1', '银行风险资本最低比率', '审慎监管提高；资本不足停止新增授信', .04, .4)
add('debt_limit', 2.5, '年', '公共债务/年产值上限', '财政信用提高则可提高；不是通用安全阈值', .2, 6)
add('money_velocity', 1.6, '1/年', '居民存款支付周转率', '信心提高；银行挤兑/冻结降低', .05, 4)
add('inflation_speed', .15, '1/年', '短缺和流动性调整物价的速度', '供需传导更快则提高', 0, .8)
add('price_food', .002, '百万MC/t', '基年生物质价格', '替代成本提高', .0005, .01)
add('price_material', .0007, '百万MC/t', '基年原料价格', '稀缺性提高', .0001, .005)
add('price_energy', .00002, '百万MC/MWh', '基年能源价格', '稀缺性提高', .000005, .0001)


def defaults():
    return {k: v.value for k, v in PARAMETERS.items()}


def validate(overrides):
    import math
    for k, v in overrides.items():
        if k not in PARAMETERS:
            raise ValueError(f'未知参数：{k}')
        p = PARAMETERS[k]
        if isinstance(v, bool) or not isinstance(v, (float, int)) or not math.isfinite(v) or not p.low <= v <= p.high:
            raise ValueError(f'{k} 必须在 [{p.low}, {p.high}] 内')


def catalogue():
    return {k: asdict(v) for k, v in PARAMETERS.items()}
