import argparse
import json
import sys
import unittest
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description='火星文明宏观动力系统仿真')
    sub=parser.add_subparsers(dest='command',required=True)
    exp=sub.add_parser('experiments',help='重建全部实验与报告')
    exp.add_argument('--years',type=int,default=40)
    exp.add_argument('--samples',type=int,default=64)
    run=sub.add_parser('simulate',help='运行单个情景')
    run.add_argument('--scenario',default='baseline')
    run.add_argument('--years',type=float,default=40)
    run.add_argument('--steps',type=int,default=12,choices=[12,24,48])
    run.add_argument('--params',type=Path,help='参数覆盖JSON文件')
    run.add_argument('--out',type=Path,default=Path('outputs/custom.json'))
    server=sub.add_parser('serve',help='本地交互面板')
    server.add_argument('--port',type=int,default=8765)
    sub.add_parser('test',help='守恒、边界与冲击机制测试')
    sub.add_parser('parameters',help='生成完整参数列表与调参指南')
    args=parser.parse_args()
    if args.command=='experiments':
        if not 10<=args.years<=100 or not 8<=args.samples<=512: parser.error('实验years需10至100，samples需8至512')
        from .experiments import generate
        rows=generate(args.years,args.samples)
        print(f'Generated {len(rows)} scenarios, policies, sensitivity, convergence and reports in outputs/')
    elif args.command=='simulate':
        from .model import simulate
        from .experiments import write_json, csv_rows
        overrides=json.loads(args.params.read_text(encoding='utf-8-sig')) if args.params else {}
        result=simulate(args.years,args.steps,args.scenario,overrides)
        args.out.parent.mkdir(parents=True,exist_ok=True)
        write_json(args.out,result)
        csv_rows(args.out.with_suffix('.csv'),result['rows'])
        print(json.dumps(result['summary'],indent=2))
    elif args.command=='serve':
        from .server import serve
        serve(args.port)
    elif args.command=='parameters':
        from .parameter_guide import main as generate_parameter_guide
        generate_parameter_guide()
    else:
        suite=unittest.defaultTestLoader.discover(str(Path(__file__).resolve().parent.parent/'tests'))
        result=unittest.TextTestRunner(verbosity=2).run(suite)
        sys.exit(0 if result.wasSuccessful() else 1)
