"""Generate a reproducible experiment pack, audits, and analysis from actual runs."""
import csv
import hashlib
import json
import random
from pathlib import Path
from .events import EVENTS
from .model import simulate, initial_state
from .parameters import catalogue
from .parameter_guide import TUNING
from .variables import catalogue as variable_catalogue

ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / 'outputs'


def parameter_catalogue():
    result = catalogue()
    for key, value in result.items():
        value['tuning'] = TUNING[key]
    return result


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def csv_rows(path, rows):
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
        for r in rows:
            w.writerow({k: json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in r.items()})


def recovery_year(result, reference):
    """All 12 consecutive monthly observations within 5% of counterfactual pop/GDP."""
    if not result['events']: return None
    end = max(e['start']+e['duration'] for e in result['events'])
    baseline = {round(r['year'],6): r for r in reference['rows']}
    streak = []
    for r in result['rows'][1:]:
        b = baseline.get(round(r['year'],6))
        if not b or r['year'] < end: continue
        ok = all(abs(r[k]/max(b[k],1e-9)-1)<=.05 for k in ('population','gdp_real'))
        if ok: streak.append(r['year'])
        else: streak=[]
        if len(streak)>=12 and streak[-1]-streak[-12]>=11/12-1e-6:
            return streak[-12]-end
    return None


def quantile(xs, p):
    xs=sorted(xs); x=(len(xs)-1)*p; i=int(x)
    return xs[i]*(1-(x-i))+xs[min(i+1,len(xs)-1)]*(x-i)


def correlation(xs, ys):
    ax=sum(xs)/len(xs); ay=sum(ys)/len(ys)
    cov=sum((x-ax)*(y-ay) for x,y in zip(xs,ys))
    variance=sum((x-ax)**2 for x in xs)*sum((y-ay)**2 for y in ys)
    return cov/variance**.5 if variance else 0.


def generate(years=40, samples=64):
    OUTPUT.mkdir(exist_ok=True)
    names=['baseline']+[e['id'] for e in EVENTS]+['compound']
    labels={'baseline':'无事件基准','compound':'沙尘＋禁运＋信用复合冲击',**{e['id']:e['name'] for e in EVENTS}}
    results={name:simulate(years=years, scenario=name) for name in names}
    base=results['baseline']; table=[]
    for name,r in results.items():
        r['label']=labels[name]
        summary=dict(scenario=name, name=labels[name], **r['summary'])
        summary['population_delta_pct']=100*(r['summary']['population']/base['summary']['population']-1)
        summary['gdp_delta_pct']=100*(r['summary']['gdp_real']/base['summary']['gdp_real']-1)
        summary['extra_deaths']=r['summary']['deaths']-base['summary']['deaths']
        summary['recovery_years']=recovery_year(r,base)
        table.append(summary)
        write_json(OUTPUT/f'{name}.json',r)
        csv_rows(OUTPUT/f'{name}.csv',r['rows'])
    policies={
        '原政策':{},
        '科研优先':{'research_share':.075, 'investment_share':.14},
        '建设优先':{'investment_share':.26, 'research_share':.025},
        '能源冗余与节能':{'availability':.95, 'life_power':.003, 'agri_energy':9},
        '低外援依赖':{'earth_grant':2.5, 'cargo_capacity':1500},
    }
    policy_rows=[]
    for label,params in policies.items():
        for scenario in ('baseline','compound'):
            r=simulate(years=years,scenario=scenario,overrides=params)
            policy_rows.append(dict(policy=label,scenario=scenario,parameters=params,**r['summary']))
    # Matched draws isolate event effects under identical uncertain structural parameters.
    rng=random.Random(20261005)
    ranges={'food_need':(.224,.336),'life_power':(.0032,.0048),'fertility':(.052,.078),
            'research_productivity':(.048,.072),'maintenance':(.0096,.0144),'import_price':(.0016,.0024)}
    draws=[]
    for i in range(samples):
        params={k:rng.uniform(*bounds) for k,bounds in ranges.items()}
        a=simulate(years=years,overrides=params)['summary']
        b=simulate(years=years,overrides=params,scenario='compound')['summary']
        draws.append(dict(draw=i,**params,population=a['population'],compound_population=b['population'],
                          effect_pct=100*(b['population']/a['population']-1),shortage_years=b['shortage_years']))
    uncertainty=dict(seed=20261005,samples=samples,ranges=ranges,
        population_quantiles={str(p):quantile([r['population'] for r in draws],p) for p in (.05,.5,.95)},
        effect_quantiles={str(p):quantile([r['effect_pct'] for r in draws],p) for p in (.05,.5,.95)},
        pearson_population={k:correlation([r[k] for r in draws],[r['population'] for r in draws]) for k in ranges})
    convergence=[]
    for name in ('baseline','compound','epidemic'):
        runs={steps:simulate(years=years,scenario=name,steps_per_year=steps)['summary'] for steps in (12,24,48)}
        for steps,r in runs.items():
            convergence.append(dict(scenario=name,steps_per_year=steps,population=r['population'],gdp_real=r['gdp_real'],
                population_error_pct=100*(r['population']/runs[48]['population']-1),
                gdp_error_pct=100*(r['gdp_real']/runs[48]['gdp_real']-1)))
    write_json(OUTPUT/'parameters.json',parameter_catalogue())
    write_json(OUTPUT/'variables.json',variable_catalogue())
    parameter_lines=['# 核心参数字典', '', 'O：近似观测约束；A：任务实例参照；H：未校准的探索性假设。范围是允许的扫描区间，不是置信区间。事件的显式乘数可能超出默认输入区间；比例变量仍限制在0—1。', '',
        '|参数|默认值|单位|名称|现象解释|输入范围|证据|', '|---|---:|---|---|---|---|---|']
    for key,p in parameter_catalogue().items():
        parameter_lines.append(f"|{key}|{p['value']:.6g}|{p['unit']}|{p['meaning']}|{p['interpretation']}|{p['low']:.6g}—{p['high']:.6g}|{p['evidence']}|")
    parameter_lines += ['', 'S2：[NASA JPL Perseverance任务说明](https://www.jpl.nasa.gov/edu/resources/teachable-moment/meet-perseverance-nasas-newest-mars-rover/)。固定结构系数另在docs/model.md公开。']
    (OUTPUT/'参数字典.md').write_text('\n'.join(parameter_lines),encoding='utf-8')
    write_json(OUTPUT/'events.json',EVENTS)
    write_json(OUTPUT/'summary.json',table)
    csv_rows(OUTPUT/'summary.csv',table)
    csv_rows(OUTPUT/'policies.csv',policy_rows)
    csv_rows(OUTPUT/'sensitivity.csv',draws)
    csv_rows(OUTPUT/'convergence.csv',convergence)
    write_json(OUTPUT/'uncertainty.json',uncertainty)
    mature=initial_state()
    mature.update(pop=[x*1.4 for x in mature['pop']],tech=[2.]*4,homes=10000.)
    export_demo=simulate(years=15,state=mature)
    write_json(OUTPUT/'export_demonstration.json',export_demo)
    csv_rows(OUTPUT/'export_demonstration.csv',export_demo['rows'])
    dashboard=dict(scenarios=results,
                   parameters=parameter_catalogue(),variables=variable_catalogue(),summary=table,policies=policy_rows,uncertainty=uncertainty,events=EVENTS,
                   variableWorkbook='../outputs/01a10adc-f58c-79d2-a85f-6ad280864ee2/变量中文名称与实际意义对照表.xlsx')
    # Embedded script lets the dashboard work offline with file:// as well as via HTTP.
    (OUTPUT/'dashboard-data.js').write_text('window.MARS_DATA='+json.dumps(dashboard,ensure_ascii=False,allow_nan=False)+';',encoding='utf-8')
    report=report_text(years,table,policy_rows,uncertainty,convergence,results)
    report += f"\n\n## 成熟阶段反哺地球演示\n\n另设初始人口7,000、四类科技指数2、住房容量10,000的成熟阶段边界测试，其他初值保持不变，运行15年。实际累计到达地球的出口为{export_demo['summary']['exports']:,.2f} t当量；首个出口收入只能在第7个月航程结束后确认。该演示不是默认殖民地已经发展到此阶段的证据，而是用于验证出口门槛及延迟结算。完整轨迹在export_demonstration.json/csv。"
    (OUTPUT/'实验报告.md').write_text(report,encoding='utf-8')
    from .report_html import render
    (OUTPUT/'实验报告.html').write_text(render(report),encoding='utf-8')
    (OUTPUT/'模型说明.html').write_text(render((ROOT/'docs'/'model.md').read_text(encoding='utf-8')),encoding='utf-8')
    (OUTPUT/'参数字典.html').write_text(render('\n'.join(parameter_lines)),encoding='utf-8')
    source_paths=sorted((ROOT/'mars_civilization').glob('*.py'))+sorted((ROOT/'tests').glob('*.py'))+[ROOT/'plan_finalver.md',ROOT/'run.py',ROOT/'web'/'index.html',ROOT/'docs'/'model.md']
    manifest=dict(model_version='1.0',client_date='2026-10-05',years=years,seed=20261005,samples=samples,
                  files={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths if p.exists()},
                  audit={k:r['audit'] for k,r in results.items()})
    write_json(OUTPUT/'manifest.json',manifest)
    return table


def report_text(years,table,policies,u,conv,results):
    b=table[0]; worst=min(table[1:],key=lambda r:r['population_delta_pct']); best=max(table[1:],key=lambda r:r['population_delta_pct'])
    lines=[f'# 火星文明动力系统仿真实验报告\n\n版本 1.0 · 2026-10-05 · {years:g} 地球年 · 每年12步 · 随机种子20261005（仅不确定性采样使用）',
    '## 结论与适用范围',
    f"本假设体系下，无事件基准从5,000人演化到{b['population']:,.0f}人；末年基年价格产值为{b['gdp_real']:.2f}百万MC/年。食物或生命保障电力不足累计{b['shortage_years']:.2f}年。最不利人口结果是“{worst['name']}”（相对基准{worst['population_delta_pct']:+.2f}%）；最有利是“{best['name']}”（{best['population_delta_pct']:+.2f}%）。这些是代码实际运行结果，不是火星人口或投资收益预测。",
    '全模型采用虚构货币MC和标准原料当量。参数未用殖民地观测数据校准；应将结果用作圆桌讨论中的机制比较和问题发现。零短缺可能表示库存充裕，也可能暴露聚合模型隐藏关键微量物资的局限。',
    '## 实验设计与边界条件',
    '初始人口5,000：少年女性/男性各900，成年各1,500，老年各100。生物质3,600 t，原料12,000 t；能源65 MW，农业3,600 t/年，工业17,000 t/年，居住容量6,500人，物流240万 t·km/年；科技各1，凝聚力0.72，价格指数1。银行初始资产=贷款12+债券20+储备36=68；负债及权益=居民存款18+企业20+财政25+股本5=68，单位百万MC。',
    '边界：单一聚合殖民地，地球是外生贸易与财政伙伴；能源为即时功率，无跨期电池库存。水、氧、辐射防护隐含在生命保障能耗与死亡风险中；无天气空间场、土地市场、真实汇率或轨道动力学。出生与交付使用确定性期望值，允许非整数人口。能源、劳动力、维护、物流、货运、资本、预算与实物库存均有上限。',
    '每个事件从第10年开始，运行相同初值和参数，只改变表中指定系数；临时系数到期恢复，受损人口、资产与已积累知识不会重置。复合情景同时施加沙尘暴、禁运与信用危机。发射窗口约26个月，航行7个月；事件不追溯取消已付款在途物资。所有资料访问日期为2026-10-05。',
    '## 事件机制与定量约束',
    '|事件|持续年数|参数变化及推理|','|---|---:|---|']
    for e in EVENTS: lines.append(f"|{e['name']}|{e['duration']}|{e['rationale']}|")
    lines += ['## 对照实验结果',
        '人口和产值变化均相对同一终止时刻的无事件基准。死亡差是累计死亡人数之差，人口规模路径也会影响它，不能直接当作因果“超额死亡率”。恢复定义为事件结束后，人口和实际产值同时回到反事实基准±5%，持续12个月；“未恢复”是观察期内未满足，并非永久不可恢复。',
        '|情景|末期人口|人口变化 %|产值变化 %|累计死亡差|短缺年数|恢复等待年|', '|---|---:|---:|---:|---:|---:|---:|']
    for r in table:
        recover='—' if r['scenario']=='baseline' else '未恢复' if r['recovery_years'] is None else f"{r['recovery_years']:.2f}"
        lines.append(f"|{r['name']}|{r['population']:,.0f}|{r['population_delta_pct']:+.2f}|{r['gdp_delta_pct']:+.2f}|{r['extra_deaths']:+.1f}|{r['shortage_years']:.2f}|{recover}|")
    lines += ['## 逐项解释：不把正向叙事预设为正向结果']
    for r in table[1:]:
        source=next((e for e in EVENTS if e['id']==r['scenario']),None)
        mechanism=source['rationale'] if source else '同步叠加电力短缺、对外输运中断和信用收缩，保留非线性资源约束。'
        lines.append(f"- **{r['name']}**：{mechanism} 末期人口变化{r['population_delta_pct']:+.2f}%，产值变化{r['gdp_delta_pct']:+.2f}%，最低食物满足率{r['min_food_ratio']:.3f}，最低生命能源满足率{r['min_life_power_ratio']:.3f}。从这些路径可检验缓冲与瓶颈；不能据此认定单一现实因果系数。")
    lines += ['## 政策比较',
        '每套政策分别在无事件和复合冲击下重跑。科研/建设政策比较支出结构；能源政策同时假设设备可用率与效率提升，未计为实现这些提升所需的一次性改造成本，因此只是技术条件反事实，不能直接比较投资回报。低外援情景同时减半拨款与货运量。',
        '|政策|环境|末期人口|实际产值 百万MC/年|短缺年数|末期债务/产值 年|', '|---|---|---:|---:|---:|---:|']
    for r in policies: lines.append(f"|{r['policy']}|{'无事件' if r['scenario']=='baseline' else '复合冲击'}|{r['population']:,.0f}|{r['gdp_real']:.2f}|{r['shortage_years']:.2f}|{r['debt_gdp']:.2f}|")
    q=u['population_quantiles']; e=u['effect_quantiles']
    lines += ['## 参数不确定性与敏感性',
        f"对食物需求、生命功率、生育率、科研生产率、维护率和进口成本分别在默认值±20%内独立均匀抽样，{u['samples']}组配对试验，每组分别运行无事件与复合冲击。基准末期人口的5%/50%/95%样本分位数为{q['0.05']:,.0f} / {q['0.5']:,.0f} / {q['0.95']:,.0f}；复合冲击人口相对效应分位数为{e['0.05']:+.2f}% / {e['0.5']:+.2f}% / {e['0.95']:+.2f}%。这不是统计置信区间；抽样分布也是假设，且未覆盖模型结构不确定性。",
        '|参数|与末期人口的 Pearson 相关|','|---|---:|']
    for k,v in sorted(u['pearson_population'].items(),key=lambda kv:-abs(kv[1])): lines.append(f'|{k}|{v:+.3f}|')
    lines += ['相关系数用于初步筛查，不能说明因果大小；强非线性和交互可能被掩盖。下一版应采用拉丁超立方/Sobol指标并对不同社会机制做模型集合。',
        '### 对反直觉结果的模型诊断',
        '默认配置的食物库存远高于一轮补给窗口，因此农业病害并未造成饥饿，甚至可能通过临时农业缺口触发追加建设，使最终人口略高于基准。这是自适应投资与过量库存共同造成的路径效应，不是“疾病有益”的现实结论。应在低库存、需求驱动进口和真实项目成本下复验。',
        '金融冲击的长期效应较弱，原因包括贷款本金持续摊还、事件发生时信用敞口已下降，以及公共配给不直接依赖居民当期支付。模型未实现企业破产停产、银行挤兑和工资拖欠反馈，因此不能据此判断金融危机不危险。',
        '生命保障人均能耗与末期人口的样本相关可能为正：当前年产值代理量把生命用电按固定价格计价，较高用电既增加能源扩建目标，也可能增加名义预算基数。在资源仍充裕时，这会掩盖低效率的代价。这一结构偏差表明下一版应采用需求满足/福利指标并引入完整净产出账户，不能将此相关用于鼓励高能耗设计。',
        '末期人口还受到住房限制的移民挤出效应：医疗降低死亡后，空置住房更少，可接纳移民也可能减少。因此总人口变化很小并不等于医疗没有价值，应同时查看累计死亡、年龄结构和移民。报告保留这些机制局限，避免以单一终点指标为政策排名。',
        '## 数值验证与守恒审计','|情景|每年步数|人口相对48步偏差 %|产值相对48步偏差 %|','|---|---:|---:|---:|']
    for r in conv: lines.append(f"|{r['scenario']}|{r['steps_per_year']}|{r['population_error_pct']:+.4f}|{r['gdp_error_pct']:+.4f}|")
    audit={k:max(r['audit'][k] for r in results.values()) for k in ('food','material','population','finance')}
    lines += [f"全部主情景逐步核对存量变化=流入−流出，最大绝对残差：生物质{audit['food']:.3e} t，原料{audit['material']:.3e} t，人口{audit['population']:.3e}人，银行资产负债{audit['finance']:.3e}百万MC。审计不等于现实有效性。死亡、折旧和存储损耗使用指数流出，所有受限实物流量按可用库存限额。事件、到港、投产和发射边界精确切分步长。",
        '## 真实性评估：证据与假设分开',
        '1. **物理环境**：[NASA Mars Facts](https://science.nasa.gov/mars/facts/)说明火星昼夜约24.6小时、年长约687地球日、稀薄大气。这里明确使用地球年；没有用地球露天农业或呼吸条件替代火星环境。下一版应加入季节、太阳辐照和纬度。',
        '2. **补给脆弱性**：[NASA JPL Perseverance任务说明](https://www.jpl.nasa.gov/edu/resources/teachable-moment/meet-perseverance-nasas-newest-mars-rover/)给出约26个月窗口与该任务七个月航程。模型据此设周期和时滞，但万吨级货运和数百人移民能力均是假设，资料并不证明这些运力可实现。',
        '3. **能源风险**：[NASA/JPL Opportunity恢复记录](https://www.jpl.nasa.gov/news/six-things-about-opportunitys-recovery-efforts/)支持沙尘遮光导致太阳能供电中断的机制。0.4可用率乘数与一年持续期是压力测试，不是该观测的数值标定；不同核能占比会改变暴露。',
        '4. **闭环生命支持**：[NASA水回收里程碑](https://www.nasa.gov/missions/station/iss-research/nasa-achieves-water-recovery-milestone-on-international-space-station/)报告ISS特定系统达到98%回收水平。它不表示物料可以100%循环或火星农业已闭合。当前把生命支持折入能耗，无法给出失水、缺氧和微量元素断供的独立风险。',
        '5. **本地制造成熟度**：[NASA MOXIE总结](https://www.nasa.gov/solar-system/nasas-oxygen-generating-experiment-moxie-completes-mars-mission/)报告累计122克氧、最佳12克/小时。实验验证机理，不验证本模型的城市工业规模。原有生产底表也自述不是闭合工程BOM；本模型没有把它的未知储量自动当作已验证产能。',
        '6. **人口与社会**：[NASA人类航天五类风险](https://www.nasa.gov/hrp/hazards/)包括辐射、隔离、距离、重力与封闭环境。火星跨代生育、寿命和社会信任参数缺少对应经验数据，当前年龄阶段、死亡系数和文艺复兴效应只能作为机制假设。',
        '7. **金融一致性**：[英格兰银行货币创造说明](https://www.bankofengland.co.uk/explainers/how-is-money-created)支持贷款创造存款、还本销毁存款的记账机制；本模型另设单一银行、固定平价结算和财政发债规则，均是制度选择而非火星金融必然形态。',
        '## 圆桌讨论的参考价值',
        '- **殖民地建设**：比较食物库存、生命保障电力、运输瓶颈和施工时滞。建议讨论满足率及最坏时期，而不是只看第40年人口。生物质过量也不能证明饮食完整或生命支持可靠。',
        '- **公共政策**：科研与基建争夺劳动和预算；援助中断具有窗口滞后；人口增长可能挤压住房。单一代表性居民无法评估收入分配、政治合法性与公平，不能把凝聚力分数当作政策福利函数。',
        '- **公司投资**：观察利用率、在途现金占用、股本损失、进口成本和技术门槛。模型没有公司间竞争、股权市场、汇率、真实成本或合同履约，因此无法输出可信NPV、IRR或推荐具体投资。应补充工程报价、分部现金流与情景折现。',
        '- **历史演化**：存量缓冲、人口年龄结构、知识积累和信用损失产生路径依赖。可比较相同事件不同发生时期；当前固定第10年、固定单次强度，尚不能估计事件概率或文明崩溃频率。',
        '- **出口反哺**：技术、人口、食物自给和储备门槛同时满足后才允许返航贸易，到达地球后确认收入；默认参数未必会在观察期内触发。高价值原料当量是商品篮子抽象，不能据此推断向地球运普通矿物可盈利。',
        '## 无量纲演化指标',
        '|指标|构造|含义与边界|','|---|---|---|',
        '|能源余裕 ΠE|可用功率 /（生命功率+潜在生产功率）|小于1表示需限产；不表示一定发生生命保障短缺|',
        '|食物自给 ΠF|年产出 / 年食物需求|大于1表示当前生产能力自给，未含营养完整性|',
        '|窗口缓冲 ΠB|食物库存 / [净年进口需求×(窗口+航程)]|小于1暴露断供；自给时输出null，表示不适用，不用巨大伪数值|',
        '|住房余裕 ΠH|居住容量 / 人口|低于1表示超员压力|',
        '|物流余裕 ΠL|有效t·km/年 / 已实现货流t·km/年|描述实现产出后的余量；应同时查看潜在吞吐满足率|',
        '|信贷安全 ΠC|银行股本 / [资本比率×(贷款+债券)]|低于1停止新增信贷；负值表示资不抵债|',
        '|财政偿息 ΠD|年债券利息 / 年税收|大于1表示税收不足以覆盖利息，未计地球拨款|',
        '|知识再生 ΠK|有效科研增长系数 / 知识折损率|需结合科技饱和项；大于1不保证科技继续增长|',
        'Pi构造以质量M、时间T、货币C、人口N和长度L为基本量纲（功率另含能量维度），每个比值分子分母量纲一致。例如B[t]、D[t/年]、τ[年]构成B/(Dτ)。这是选定过程的候选相似指标，不声称给出了整个非线性混合时滞系统的一组完备独立Pi基，也不能用量纲定理推导社会因果。完整参数和状态见模型说明。',
        '## 已知局限与改进优先级',
        '1. **优先级P0**：将水、氧、可食营养、关键备件与电子件从三类总资源中分离；使用工程BOM连接原有生产模型，明确反应计量、联产与外部依赖，避免原料无限可替代。',
        '2. **P0**：年龄改为逐岁或生育年龄分组，增加辐射累积和健康状态、移民筛选、医疗容量；火星生殖数据缺失应以多模型上下界处理。',
        '3. **P1**：多城市节点、运输网络和能源结构，显式电池储能、故障、维修、季节和资源可采储量；对灾害分布与相关性抽样。',
        '4. **P1**：金融增设企业资产负债表、坏账与欠息、银行清算/再资本化、居民异质性和市场出清；当前短缺采用公共配给，销售不足不会立刻使实际生产停工。',
        '5. **P1**：增加参数后验校准、工程专家审查、多个冲击时点与强度扫描；把相关参数联合采样，加入Sobol敏感性和结构不确定性。',
        '6. **P2**：引入政策目标权重和成本相同的方案对照，再做鲁棒优化；不把未计资本开支的效率改善当成免费政策。',
        '## 复现与产物',
        '`python run.py experiments` 可重建本报告、16个主情景、10个政策对照、64组配对敏感性试验以及三种情景的步长比较。`python run.py test` 执行独立边界与守恒测试。`python run.py serve` 启动本地交互面板。',
        'outputs/ 内含完整逐步CSV/JSON、summary.csv、policies.csv、sensitivity.csv、convergence.csv、parameters.json、events.json和带代码SHA-256的manifest.json。每行库存是步末量，产率为该步年化流率，food_import等为该步实际数量；首行只有初始存量。时域为[0,终止年)，恰在终点到港或投产的项目保留在boundary队列。']
    return '\n\n'.join(lines)
