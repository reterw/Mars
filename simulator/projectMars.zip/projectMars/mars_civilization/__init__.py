"""Mars civilization: reproducible, stock-flow-consistent scenario laboratory."""
