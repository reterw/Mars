"""Events change coefficients on a half-open time interval; no hidden state edits."""


def event(id, name, start, duration, changes, rationale):
    return dict(id=id, name=name, start=start, duration=duration, changes=changes, rationale=rationale)


EVENTS = [
    event('dust', '全球沙尘暴', 10, 1, {'availability': .4, 'transport_energy': 1.6},
          '先影响发电可用率和物流能耗：可用率乘0.4、物流能耗乘1.6；一年冲击不等同于已观测灾害频率。'),
    event('epidemic', '传染病暴发', 10, 2, {'epidemic': {'add': .025}, 'participation': .72, 'fertility': .75},
          '先增加死亡风险，再削弱劳动与生育：附加风险每年0.025，参与率乘0.72，生育率乘0.75。'),
    event('conflict', '殖民地内部冲突', 10, 3, {'cohesion_target': .45, 'default_rate': 12, 'maintenance': 1.8, 'epidemic': {'add': .008}},
          '通过社会信任、信用核销、设施损耗及暴力伤亡作用，而非直接扣减抽象文明分数。'),
    event('embargo', '地球禁运与断援', 10, 6, {'earth_grant': 0, 'cargo_capacity': 0, 'passenger_capacity': 0},
          '停止新拨款和新发射；已在途船只仍按原计划到达。'),
    event('crop_disease', '农业病害', 10, 2, {'food_yield': .45, 'food_loss': 2},
          '生产率乘0.45、储存损耗率乘2；已有库存逐步缓冲冲击。'),
    event('ice', '浅层富集矿区发现', 10, 10, {'mining_yield': 1.35, 'mine_energy': .7},
          '原料产率提高35%、能耗降低30%；不声称火星已探明对应可采储量。'),
    event('breakthrough', '自动化与科研突破', 10, 10, {'research_productivity': 1.7, 'labor_per_food': .7, 'labor_per_material': .7},
          '科研生产率提高70%，农业工业劳动系数降低30%；知识通过积累保留。'),
    event('art', '跨殖民地文艺复兴', 10, 5, {'cohesion_target': 1.3, 'research_productivity': 1.15},
          '文化作品提升信任目标30%、知识传播效率15%；不直接生产食物或发电。'),
    event('harvest', '连续丰收', 10, 2, {'food_yield': 1.5, 'food_loss': .7},
          '农业生产系数提高50%、储存损耗降低30%；检验能源或运输瓶颈能否吞噬收益。'),
    event('credit', '金融信用危机', 10, 3, {'default_rate': 20, 'loan_rate': 2.5, 'money_velocity': .35},
          '核销率由0.005升至0.1/年、贷款利率乘2.5、居民周转率乘0.35。'),
    event('migration', '地球移民潮', 10, 5, {'migration': 3, 'passenger_capacity': 2},
          '意愿乘3，客运上限乘2；实际落地仍受资金、窗口、居住空间约束。'),
    event('medicine', '医疗突破', 10, 10, {'death_child': .55, 'death_adult': .6, 'death_old': .7},
          '各年龄死亡风险分别降低45%、40%、30%；寿命改善会反馈养老和资源需求。'),
    event('logistics', '运输走廊失效', 10, 3, {'distance': 2.5, 'transport_energy': 2},
          '平均距离乘2.5、吨公里能耗乘2；内部吞吐和生产电力同时受到约束。'),
    event('aid', '地球合作与援助扩张', 10, 5, {'earth_grant': 2, 'cargo_capacity': 1.5, 'delivery_success': {'set': .995}},
          '拨款翻倍、货运上限提高50%、成功交付比例升至0.995；检查资金与实物的区别。'),
]


def scenario_events(name):
    if name == 'baseline':
        return []
    if name == 'compound':
        return [e.copy() for e in EVENTS if e['id'] in ('dust', 'embargo', 'credit')]
    for e in EVENTS:
        if e['id'] == name:
            return [e.copy()]
    raise ValueError(f'未知情景：{name}')
