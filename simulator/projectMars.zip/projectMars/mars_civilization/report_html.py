"""Tiny safe renderer for the generated Markdown subset (no external assets)."""
import html
import re


def inline(text):
    s=html.escape(text)
    s=re.sub(r'\[([^\]]+)\]\((https://[^)]+)\)',r'<a href="\2">\1</a>',s)
    s=re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',s)
    return re.sub(r'`([^`]+)`',r'<code>\1</code>',s)


def render(markdown):
    parts=[]; table=False; fenced=False
    for line in markdown.splitlines():
        line=line.strip()
        if line.startswith('```'):
            if table: parts.append('</table></div>'); table=False
            parts.append('</code></pre>' if fenced else '<pre><code>')
            fenced=not fenced
            continue
        if fenced:
            parts.append(html.escape(line)+'\n')
            continue
        if not line: continue
        if line.startswith('|'):
            if re.fullmatch(r'[|:\- ]+',line): continue
            if not table: parts.append('<div class="scroll"><table>'); table=True
            parts.append('<tr>'+''.join('<td>'+inline(x.strip())+'</td>' for x in line.strip('|').split('|'))+'</tr>')
            continue
        if table: parts.append('</table></div>'); table=False
        if line.startswith('#'):
            count=len(line)-len(line.lstrip('#'))
            parts.append(f'<h{count}>'+inline(line[count:].strip())+f'</h{count}>')
        else: parts.append('<p>'+inline(line)+'</p>')
    if table: parts.append('</table></div>')
    title=html.escape(markdown.splitlines()[0].lstrip('# '))
    return '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'''+title+'''</title><style>
    *{box-sizing:border-box}body{background:#f6f3ed;color:#263435;font:16px/1.9 system-ui,"Microsoft YaHei",sans-serif;margin:0}main{max-width:1040px;margin:auto;padding:48px 32px}a{color:#986035}h1{font-size:36px;line-height:1.3}h2{margin-top:45px;border-top:1px solid #d4cec5;padding-top:22px;color:#1d4b4a}p{margin:15px 0}table{border-collapse:collapse;width:100%;font-size:14px}td{padding:10px 12px;border-bottom:1px solid #d4cec5;text-align:left}tr:first-child{font-weight:700;background:#e8e3da}.scroll{overflow-x:auto}code{background:#e9e4dc;padding:2px 5px;border-radius:4px}@media print{body{background:white}main{padding:0}h2{break-after:avoid}tr{break-inside:avoid}a{color:inherit}}
    pre{background:#e9e4dc;padding:16px;overflow-x:auto;font-size:13px;line-height:1.65}pre code{padding:0}
    </style><main><a href="../web/index.html">← 返回文明观测台</a>'''+''.join(parts)+'</main></html>'
