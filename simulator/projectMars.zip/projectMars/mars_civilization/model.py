"""Deterministic expected-value, resource-constrained civilization dynamics.

Time is Earth years; power MW; goods tonnes; money million fictitious MC.
No external Python dependency. See docs/model.md for equations and limitations.
"""
import copy
import math
from .parameters import defaults, validate
from .events import scenario_events

HOURS = 8766.0  # 365.25 * 24, bookkeeping conversion, not a Martian sol


def clamp(x, low=0., high=1.):
    return min(high, max(low, x))


def initial_state():
    return dict(pop=[900., 900., 1500., 1500., 100., 100.], food=3600., material=12000.,
                energy_cap=65., food_cap=3600., mine_cap=17000., homes=6500., transport_cap=2400000.,
                tech=[1., 1., 1., 1.], cohesion=.72, price=1.,
                household=18., firms=20., treasury=25., loans=12., bonds=20., reserves=36., equity=5.,
                cumulative_deaths=0., cumulative_births=0., cumulative_arrivals=0., cumulative_departures=0.,
                cumulative_imports=0., cumulative_exports=0., cumulative_defaults=0.)


def effective(base, events, t):
    p = base.copy()
    active = []
    for e in events:
        if e['start'] - 1e-9 <= t < e['start'] + e['duration'] - 1e-9:
            active.append(e['id'])
            for key, value in e['changes'].items():
                if isinstance(value, dict):
                    p[key] = value.get('set', p[key] + value.get('add', 0))
                else:
                    p[key] *= value
    for key in ('cohesion_target', 'participation', 'delivery_success', 'female_birth', 'migration_female', 'availability'):
        p[key] = clamp(p[key])
    return p, active


def simulate(years=40, steps_per_year=12, scenario='baseline', overrides=None, state=None):
    if isinstance(years, bool) or not isinstance(years, (int, float)) or not math.isfinite(years) or years < 1:
        raise ValueError('years 必须是不小于1的有限数')
    if steps_per_year not in (12, 24, 48):
        raise ValueError('steps_per_year 必须是12、24或48')
    validate(overrides or {})
    base = defaults()
    base.update(overrides or {})
    events = scenario_events(scenario)
    s = copy.deepcopy(initial_state() if state is None else state)
    initial = copy.deepcopy(s)
    ships, projects, log, rows = [], [], [], []
    next_window = 0.
    last_gdp = 15.
    last_food_ratio = 1.
    audit = dict(food=0., material=0., population=0., finance=0., minimum_stock=math.inf)
    dt = 1 / steps_per_year

    def transfer(src, dst, amount):
        paid = min(max(0., amount), s[src])
        s[src] -= paid
        s[dst] += paid
        return paid

    def payment(amount, payer='treasury'):
        paid = min(max(0., amount), s[payer], s['reserves'])
        s[payer] -= paid
        s['reserves'] -= paid
        return paid

    def row(t, flows=None, active=None):
        n = sum(s['pop'])
        p, _ = effective(base, events, max(0, t - 1e-8))
        r = {k: v for k, v in s.items() if not isinstance(v, list)}
        r.update(year=t, population=n, children=sum(s['pop'][:2]), adults=sum(s['pop'][2:4]),
                 elderly=sum(s['pop'][4:]), female_fraction=sum(s['pop'][::2])/max(n, 1e-9),
                 tech_energy=s['tech'][0], tech_food=s['tech'][1], tech_industry=s['tech'][2], tech_health=s['tech'][3],
                 money=s['household']+s['firms']+s['treasury'], debt_gdp=s['bonds']/max(last_gdp*s['price'], 1e-9),
                 food_years=s['food']/max(n*p['food_need'], 1e-9),
                 housing_ratio=s['homes']/max(n, 1e-9), active=active or [],
                 in_transit=sum(x['food']+x['material'] for x in ships if x['kind']=='import'),
                 pending_projects=len(projects), bank_residual=s['loans']+s['bonds']+s['reserves']-s['household']-s['firms']-s['treasury']-s['equity'])
        r.update(flows or {})
        rows.append(r)

    row(0)
    t = 0.
    while t < years - 1e-9:
        # Split at every arrival, commissioning, policy boundary, and launch window.
        boundaries = [years, t + dt, next_window]
        boundaries += [x['arrival'] for x in ships] + [x['due'] for x in projects]
        boundaries += [v for e in events for v in (e['start'], e['start']+e['duration'])]
        for x in projects[:]:
            if x['due'] <= t + 1e-8:
                s[x['key']] += x['capacity']
                projects.remove(x)
        p, active = effective(base, events, t)
        food0, mat0, pop0 = s['food'], s['material'], sum(s['pop'])
        food_in = mat_in = people_in = 0.
        for x in ships[:]:
            if x['arrival'] <= t + 1e-8:
                if x['kind'] == 'import':
                    food_in += x['food']; mat_in += x['material']; people_in += x['people']
                    s['food'] += x['food']; s['material'] += x['material']
                    s['pop'][2] += x['people'] * x['female']
                    s['pop'][3] += x['people'] * (1-x['female'])
                    s['cumulative_imports'] += x['food']+x['material']
                    s['cumulative_arrivals'] += x['people']
                else:
                    s['firms'] += x['revenue']; s['reserves'] += x['revenue']
                    s['cumulative_exports'] += x['material']*x['success']
                log.append(dict(year=t, kind='arrival', detail=x.copy()))
                ships.remove(x)
        # Windows are discrete; import spending precedes launch, revenue follows export arrival.
        exported = departed = 0.
        if next_window <= t + 1e-8:
            n = sum(s['pop'])
            desired_people = min(p['passenger_capacity'], p['migration']*p['window']*s['cohesion'], max(0, s['homes']-n))
            desired_cargo = p['cargo_capacity']
            cost = desired_people*p['passenger_price'] + desired_cargo*p['import_price']
            fraction = min(1., s['treasury']/max(cost, 1e-9), s['reserves']/max(cost, 1e-9))
            payment(cost*fraction)
            delivered = fraction*p['delivery_success']
            ship = dict(kind='import', arrival=t+p['flight'], food=desired_cargo*p['import_food_fraction']*delivered,
                        material=desired_cargo*(1-p['import_food_fraction'])*delivered,
                        people=desired_people*delivered, female=p['migration_female'])
            ships.append(ship)
            # Return migration is possible only at a window and uses its own passenger capacity.
            desired_out = min(p['passenger_capacity'], n*p['emigration']*p['window']*(1-s['cohesion']))
            departed = payment(desired_out*p['passenger_price'], 'household')/p['passenger_price']
            for j in range(6):
                s['pop'][j] *= 1-departed/max(n, 1e-9)
            s['cumulative_departures'] += departed
            if min(s['tech'][:3]) >= p['export_tech'] and n >= p['export_population'] and last_food_ratio >= 1-1e-8 and s['food'] >= n*p['food_need']*p['reserve_food_years']:
                spare = max(0., s['material']-p['reserve_material_years']*p['maintenance']*capital_material(s, p))
                exported = min(p['export_capacity'], spare, s['firms']/max(p['export_freight'], 1e-9), s['reserves']/max(p['export_freight'], 1e-9))
                payment(exported*p['export_freight'], 'firms')
                s['material'] -= exported
                ships.append(dict(kind='export', arrival=t+p['flight'], material=exported, success=p['delivery_success'],
                                  revenue=exported*p['export_price']*p['delivery_success']))
            log.append(dict(year=t, kind='launch', cargo=desired_cargo*fraction, immigrants=desired_people*fraction,
                            exported=exported, departed=departed, active=active))
            next_window += p['window']
        boundaries += [next_window] + [x['arrival'] for x in ships]
        h = min(v for v in boundaries if v > t+1e-8) - t
        n = sum(s['pop']); adult = sum(s['pop'][2:4])
        te, ta, ti, th = s['tech']
        workforce = adult*p['participation']*(.5+.5*s['cohesion'])
        research_workers = workforce*p['research_share']
        available_workers = workforce-research_workers
        required_workers = (s['energy_cap']*p['labor_per_mw'] + s['food_cap']*p['labor_per_food'] + s['mine_cap']*p['labor_per_material'] + s['transport_cap']*p['labor_per_transport'])
        labor = min(1., available_workers/max(required_workers, 1e-9))
        build_workers = max(0., available_workers-required_workers*labor)
        # Annualized power balance: maintenance/food protection via life support first.
        power = s['energy_cap']*p['availability']*te*labor
        life_demand = n*p['life_power']/math.sqrt(th)
        life_used = min(power, life_demand)
        life_ratio = min(1., power/max(life_demand, 1e-9))
        remaining_energy = max(0., power-life_used)*HOURS
        potential_food = s['food_cap']*p['food_yield']*ta*labor
        potential_material = s['mine_cap']*p['mining_yield']*ti*labor
        logistics = s['transport_cap']*math.sqrt(ti)*labor
        transport_ratio = min(1., logistics/max((potential_food+potential_material)*p['distance'], 1e-9))
        potential_food *= transport_ratio; potential_material *= transport_ratio
        food_energy = p['agri_energy']/math.sqrt(ta) + p['distance']*p['transport_energy']
        mine_energy = p['mine_energy']/math.sqrt(ti) + p['distance']*p['transport_energy']
        # Ration scarce production power proportionally, not separately twice.
        production_ratio = min(1., remaining_energy/max(potential_food*food_energy+potential_material*mine_energy, 1e-9))
        q_food = potential_food*production_ratio; q_mat = potential_material*production_ratio
        production_energy = q_food*food_energy+q_mat*mine_energy
        build_energy = max(0., remaining_energy-production_energy)
        s['food'] += q_food*h; s['material'] += q_mat*h
        food_loss = s['food']*(-math.expm1(-p['food_loss']*h))
        material_loss = s['material']*(-math.expm1(-p['material_loss']*h))
        s['food'] -= food_loss; s['material'] -= material_loss
        demand = n*p['food_need']*h
        food_used = min(s['food'], demand); s['food'] -= food_used
        food_ratio = min(1., food_used/max(demand, 1e-9)); last_food_ratio = food_ratio
        maintenance_need = capital_material(s, p)*p['maintenance']*h
        maintained = min(s['material'], maintenance_need); s['material'] -= maintained
        maintenance_ratio = min(1., maintained/max(maintenance_need, 1e-9))
        # Fixed-base value-added proxy removes in-sector energy and maintenance intermediates.
        used_energy = life_used*HOURS+production_energy
        gdp = max(0., q_food*p['price_food']+q_mat*p['price_material']+life_used*HOURS*p['price_energy']-maintained/h*p['price_material'])
        nominal = gdp*s['price']; last_gdp = gdp
        grant = p['earth_grant']*h
        s['treasury'] += grant; s['reserves'] += grant
        # Bank credit creates deposits; capital limits apply to both loans and public bonds.
        loan_need = max(0., nominal*p['wage_share']*h-s['firms'])
        headroom = max(0., s['equity']/p['capital_ratio']-s['loans']-s['bonds'])
        credit = min(loan_need, headroom)
        s['loans'] += credit; s['firms'] += credit
        wages = transfer('firms', 'household', nominal*p['wage_share']*h)
        wage_tax = transfer('household', 'treasury', wages*p['tax_rate'])
        sales = transfer('household', 'firms', min(nominal*h, s['household']*p['money_velocity']*h))
        sales_tax = transfer('firms', 'treasury', sales*p['tax_rate'])
        interest_f = min(s['firms'], s['loans']*p['loan_rate']*h)
        s['firms'] -= interest_f; s['equity'] += interest_f
        interest_g = min(s['treasury'], s['bonds']*p['bond_rate']*h)
        s['treasury'] -= interest_g; s['equity'] += interest_g
        principal = min(s['firms'], s['loans']*p['loan_amortization']*h)
        s['firms'] -= principal; s['loans'] -= principal
        default = s['loans']*(-math.expm1(-(p['default_rate']+.08*(1-food_ratio)+.05*(1-life_ratio))*h))
        s['loans'] -= default; s['equity'] -= default; s['cumulative_defaults'] += default
        budget = nominal*(p['investment_share']+p['research_share'])*h
        bond_space = max(0., p['debt_limit']*nominal-s['bonds'])
        capital_space = max(0., s['equity']/p['capital_ratio']-s['loans']-s['bonds'])
        issued = min(max(0., budget-s['treasury']), bond_space, capital_space)
        s['bonds'] += issued; s['treasury'] += issued
        research = transfer('treasury', 'household', nominal*p['research_share']*h)
        funding = (research/h)/(p['research_scale']+research/h)
        scientist = min(1., research_workers/max(.02*n, 1e-9))
        for j in range(4):
            growth = p['research_productivity']*funding*scientist*s['cohesion']*life_ratio*food_ratio
            rate = growth*(1-s['tech'][j]/p['tech_ceiling'])-p['knowledge_decay']
            s['tech'][j] = max(.3, s['tech'][j]*math.exp(rate*h))
        # Adaptive expansion priorities; pending capital prevents repeated orders.
        pending = {key: sum(x['capacity'] for x in projects if x['key']==key) for key in CAPACITIES}
        targets = dict(energy_cap=(life_demand+(n*p['food_need']*food_energy+max(5000., n*2)*mine_energy)/HOURS)*1.5/max(p['availability']*te, .05),
                       food_cap=n*p['food_need']*1.6/max(p['food_yield']*ta, .05),
                       mine_cap=max(5000., n*2)/max(p['mining_yield']*ti, .05), homes=n*1.35,
                       transport_cap=(potential_food+potential_material)*p['distance']*1.35/max(math.sqrt(ti), .1))
        gaps = {key: max(0., targets[key]-s[key]-pending[key])*p[coefficient] for key, coefficient in CAPACITIES.items()}
        total_gap = sum(gaps.values())
        material_spare = max(0., s['material']-capital_material(s,p)*p['maintenance']*p['reserve_material_years'])
        unit_cost = p['build_price']*s['price']
        build = min(total_gap, material_spare, build_energy*h/p['build_energy'], build_workers*h/p['build_labor'],
                    s['treasury']/unit_cost, nominal*p['investment_share']*h/unit_cost)
        s['material'] -= build
        investment = transfer('treasury', 'firms', build*unit_cost)
        for key, coefficient in CAPACITIES.items():
            if build > 1e-12 and gaps[key] > 0:
                projects.append(dict(key=key, capacity=build*gaps[key]/total_gap/p[coefficient], due=t+h+p['build_delay']))
            s[key] *= math.exp(-(p['depreciation']+p['unmaintained_decay']*(1-maintenance_ratio))*h)
        # Demography: competing aging/death hazards avoid creating negative cohorts.
        crowd = max(0., n/max(s['homes'], 1e-9)-1)
        stress = (1-food_ratio)+(1-life_ratio)
        extra = p['epidemic']+p['shortage_mortality']*stress+p['crowding_mortality']*crowd
        old = s['pop'][:]; new = [0.]*6; deaths = 0.
        for j, count in enumerate(old):
            stage = j//2
            death = (p[('death_child','death_adult','death_old')[stage]]+extra)/math.sqrt(th)
            aging = (1/p['child_years'] if stage==0 else 1/p['adult_years'] if stage==1 else 0.)
            moved = count*(-math.expm1(-(death+aging)*h))
            deceased = moved*death/max(death+aging, 1e-12)
            aged = moved-deceased
            new[j] += count-moved
            if stage<2: new[j+2] += aged
            deaths += deceased
        reproductive_pairs = min(old[2], old[3])
        births = reproductive_pairs*p['fertility']*s['cohesion']*food_ratio*life_ratio*min(1., s['homes']/max(n,1e-9))*h
        new[0] += births*p['female_birth']; new[1] += births*(1-p['female_birth'])
        s['pop'] = new; s['cumulative_births'] += births; s['cumulative_deaths'] += deaths
        s['cohesion'] = clamp(s['cohesion']+h*(p['cohesion_speed']*(p['cohesion_target']-s['cohesion'])-p['cohesion_stress']*stress-.03*crowd))
        money_pressure = clamp((s['household']*p['money_velocity'])/max(nominal, 1e-9)-1, -.5, 1)
        inflation = p['inflation_speed']*(stress+.3*money_pressure)
        s['price'] *= math.exp(clamp(inflation,-.5,1)*h)
        residual_food = s['food']-(food0+food_in+q_food*h-food_loss-food_used)
        residual_mat = s['material']-(mat0+mat_in+q_mat*h-material_loss-maintained-build-exported)
        residual_pop = sum(s['pop'])-(pop0+people_in-departed+births-deaths)
        residual_bank = s['loans']+s['bonds']+s['reserves']-s['household']-s['firms']-s['treasury']-s['equity']
        for key, val in [('food',residual_food),('material',residual_mat),('population',residual_pop),('finance',residual_bank)]:
            audit[key] = max(audit[key], abs(val))
        nonnegative = [s[k] for k in ('food','material','energy_cap','food_cap','mine_cap','homes','transport_cap','household','firms','treasury','loans','bonds','reserves')] + s['pop']
        audit['minimum_stock'] = min(audit['minimum_stock'], *nonnegative)
        if not all(math.isfinite(v) for v in nonnegative) or min(nonnegative) < -1e-8:
            raise ArithmeticError('状态非有限或库存为负')
        # Dimensionless resilience ratios; infinite quantities represented by null in JSON.
        pi_energy = power/max(life_demand+(potential_food*food_energy+potential_material*mine_energy)/HOURS, 1e-9)
        food_dependence = max(0., n*p['food_need']-q_food)
        pi_buffer = s['food']/max(food_dependence*(p['window']+p['flight']), 1e-9) if food_dependence > 1e-8 else None
        flows = dict(dt=h, gdp_real=gdp, gdp_nominal=nominal, power=power, life_power_ratio=life_ratio, food_ratio=food_ratio,
                     food_output=q_food, material_output=q_mat, food_consumption=food_used/h, births=births/h, deaths=deaths/h,
                     labor_ratio=labor, transport_ratio=transport_ratio, energy_production_ratio=production_ratio,
                     maintenance_ratio=maintenance_ratio, investment=investment/h, research=research/h, inflation=inflation,
                     food_import=food_in, material_import=mat_in, arrivals=people_in, departures=departed, exports_launched=exported,
                     food_loss=food_loss, material_loss=material_loss, construction_material=build, maintenance_material=maintained,
                     energy_used=(used_energy+build*p['build_energy']/h)/HOURS,
                     pi_energy=pi_energy, pi_food=q_food/max(n*p['food_need'],1e-9), pi_buffer=pi_buffer,
                     pi_housing=s['homes']/max(n,1e-9), pi_logistics=logistics/max((q_food+q_mat)*p['distance'],1e-9),
                     pi_credit=s['equity']/max(p['capital_ratio']*(s['loans']+s['bonds']),1e-9),
                     pi_debt=s['bonds']*p['bond_rate']/max((wage_tax+sales_tax)/h,1e-9),
                     pi_knowledge=p['research_productivity']*funding*scientist*s['cohesion']/max(p['knowledge_decay'],1e-9))
        t += h
        row(t, flows, active)
    return dict(scenario=scenario, years=years, steps_per_year=steps_per_year, parameters=base, initial=initial,
                events=events, rows=rows, log=log, audit=audit, final_state=s,
                boundary={'incoming_ships': ships, 'construction_pipeline': projects}, summary=summarize(rows, events))


CAPACITIES = dict(energy_cap='material_per_mw', food_cap='material_per_food', mine_cap='material_per_mine',
                  homes='material_per_home', transport_cap='material_per_transport')


def capital_material(s,p):
    return sum(s[key]*p[coefficient] for key,coefficient in CAPACITIES.items())


def summarize(rows, events):
    r = rows[-1]; steps=rows[1:]
    return dict(population=r['population'], gdp_real=r['gdp_real'], food_years=r['food_years'],
                min_food_ratio=min(x['food_ratio'] for x in steps), min_life_power_ratio=min(x['life_power_ratio'] for x in steps),
                shortage_years=sum(x['dt'] for x in steps if x['food_ratio']<.99 or x['life_power_ratio']<.99),
                deaths=r['cumulative_deaths'], births=r['cumulative_births'], arrivals=r['cumulative_arrivals'],
                exports=r['cumulative_exports'], debt_gdp=r['debt_gdp'], equity=r['equity'], price=r['price'],
                min_equity=min(x['equity'] for x in rows), cohesion=r['cohesion'])
