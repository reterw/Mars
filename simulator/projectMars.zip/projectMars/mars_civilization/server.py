"""Loopback-only read/run server. No writes, no external dependencies."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit
import json
import threading
from .model import simulate
from .experiments import ROOT
from .parameters import validate


PARAMETER_SETTINGS = ROOT / 'outputs' / '用户参数设置.json'
PARAMETER_SETTINGS_LOCK = threading.Lock()


def load_parameter_settings():
    if not PARAMETER_SETTINGS.exists():
        return {}
    data = json.loads(PARAMETER_SETTINGS.read_text(encoding='utf-8-sig'))
    if not isinstance(data, dict):
        raise ValueError('本地参数设置必须是JSON对象')
    validate(data)
    return data


def save_parameter_settings(overrides):
    if not isinstance(overrides, dict):
        raise ValueError('overrides必须是对象')
    validate(overrides)
    PARAMETER_SETTINGS.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(overrides, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    temporary = PARAMETER_SETTINGS.with_suffix('.json.tmp')
    with PARAMETER_SETTINGS_LOCK:
        temporary.write_text(payload, encoding='utf-8')
        temporary.replace(PARAMETER_SETTINGS)
    return overrides


class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,directory=str(ROOT),**kwargs)

    def do_GET(self):
        path=urlsplit(self.path).path
        if path=='/api/parameters':
            try: return self.respond(200,{'overrides':load_parameter_settings(),'path':'outputs/用户参数设置.json'})
            except (ValueError,TypeError,KeyError,json.JSONDecodeError) as e: return self.respond(500,{'error':str(e)})
        if path=='/': self.path='/web/index.html'
        super().do_GET()

    def respond(self,status,body):
        payload=json.dumps(body,ensure_ascii=False,allow_nan=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(payload)))
        self.send_header('Cache-Control','no-store')
        self.end_headers(); self.wfile.write(payload)

    def do_POST(self):
        path=urlsplit(self.path).path
        if path not in ('/api/simulate','/api/parameters'): return self.respond(404,{'error':'接口不存在'})
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=32000: raise ValueError('请求正文长度无效')
            data=json.loads(self.rfile.read(length))
            if not isinstance(data,dict): raise ValueError('请求必须是JSON对象')
            if path=='/api/parameters':
                if set(data)!={'overrides'}: raise ValueError('参数设置请求只允许overrides字段')
                saved=save_parameter_settings(data['overrides'])
                return self.respond(200,{'overrides':saved,'path':'outputs/用户参数设置.json'})
            allowed={'years','steps_per_year','scenario','overrides'}
            if set(data)-allowed: raise ValueError('请求包含未知字段')
            if not isinstance(data.get('overrides',{}),dict): raise ValueError('overrides必须是对象')
            if not isinstance(data.get('scenario','baseline'),str): raise ValueError('scenario必须是字符串')
            result=simulate(**data)
            self.respond(200,result)
        except (ValueError,TypeError,KeyError) as e:
            self.respond(400,{'error':str(e)})


def serve(port=8765):
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    print(f'Mars Observatory: http://127.0.0.1:{port}',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
