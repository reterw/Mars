"""Render a complete, human-oriented tuning guide from parameters.py."""
from pathlib import Path

from .parameters import PARAMETERS


GROUPS = {
    "一、资源、生产与劳动": [
        "availability", "food_yield", "mining_yield", "food_need", "life_power",
        "agri_energy", "mine_energy", "transport_energy", "distance", "food_loss",
        "material_loss", "maintenance", "depreciation", "unmaintained_decay",
        "labor_per_mw", "labor_per_food", "labor_per_material", "labor_per_transport",
        "participation",
    ],
    "二、人口、健康与迁徙": [
        "fertility", "female_birth", "death_child", "death_adult", "death_old",
        "child_years", "adult_years", "shortage_mortality", "crowding_mortality",
        "epidemic", "migration", "migration_female", "emigration",
    ],
    "三、社会凝聚力与科技": [
        "cohesion_target", "cohesion_speed", "cohesion_stress", "research_share",
        "research_productivity", "research_scale", "tech_ceiling", "knowledge_decay",
    ],
    "四、建设、扩张与战略储备": [
        "investment_share", "material_per_mw", "material_per_food", "material_per_mine",
        "material_per_home", "material_per_transport", "build_price", "build_energy",
        "build_labor", "build_delay", "reserve_food_years", "reserve_material_years",
    ],
    "五、地火运输、进口与出口": [
        "window", "flight", "cargo_capacity", "passenger_capacity", "delivery_success",
        "import_food_fraction", "import_price", "passenger_price", "earth_grant",
        "export_tech", "export_population", "export_capacity", "export_price",
        "export_freight",
    ],
    "六、财政、银行与价格": [
        "tax_rate", "wage_share", "loan_rate", "bond_rate", "loan_amortization",
        "default_rate", "capital_ratio", "debt_limit", "money_velocity",
        "inflation_speed", "price_food", "price_material", "price_energy",
    ],
}


TUNING = {
    "availability": "上调表示冗余、检修和可靠性改善，可用电力增加；下调表示故障、沙尘遮光或停机增多。",
    "food_yield": "上调模拟丰收、良种或栽培突破；下调模拟病害、光照不足或营养液失效。",
    "mining_yield": "上调模拟富矿、选冶和采掘进步；下调模拟贫矿、枯竭或设备受损。",
    "food_need": "上调增加人均食物需求与库存压力，可模拟浪费或更高营养供给；下调模拟节约和损耗控制，不宜低于基本营养边界。",
    "life_power": "上调表示保温、制氧、水循环等效率下降，生命保障用电增加；下调表示建筑隔热和闭环系统改善。",
    "agri_energy": "上调表示人工照明、温控成本增加；下调表示LED、自然采光或温室热管理效率提高。",
    "mine_energy": "上调模拟贫矿、深层采掘和高温加工；下调模拟选址、装备或冶炼效率改善。",
    "transport_energy": "上调模拟路况恶化、载具低效或频繁绕行；下调模拟车辆、电网和线路效率改善。",
    "distance": "上调模拟城市分散和采矿前沿外移；下调模拟紧凑布局、就地加工或生产节点重组。",
    "food_loss": "上调模拟冷链或仓储失效；下调模拟密封、温控、库存周转和回收改善。",
    "material_loss": "上调模拟腐蚀、泄漏和不可回收废料增加；下调模拟防护和循环利用改善。",
    "maintenance": "上调表示恶劣环境或老化使年度维护材料需求增加；下调表示模块化、耐久性和预防维护改善。",
    "depreciation": "上调使正常维护下的设施折旧更快；下调模拟长寿命设计与更耐久材料。",
    "unmaintained_decay": "上调会放大缺少维护时的产能损失；下调表示设备可容错、可降级运行或易维修。",
    "labor_per_mw": "上调增加每MW能源设施所需人员；下调模拟自动化、远程运维和标准化。",
    "labor_per_food": "上调增加单位农业产能的人力需求；下调模拟农业机器人和自动环境控制。",
    "labor_per_material": "上调增加单位工业/采集产能的人力需求；下调模拟自主采矿和柔性制造。",
    "labor_per_transport": "上调增加单位物流运力的人力需求；下调模拟自动驾驶、自动装卸和集中调度。",
    "participation": "上调表示更多成年人进入有效劳动供给；下调模拟疾病、培训、照护负担或社会失序。",
    "fertility": "上调提高每对成年男女的有效出生率，可模拟育儿支持与安全感改善；下调模拟生育推迟、健康风险或居住压力。",
    "female_birth": "仅用于出生性别结构情景：上调增加女性新生儿占比，下调则减少；不建议把它作为政策优化旋钮。",
    "death_child": "上调模拟儿科医疗、营养或环境恶化；下调模拟公共卫生、医疗和防护改善。",
    "death_adult": "上调模拟辐射、事故、疾病和医疗不足；下调模拟防护、医疗和工作安全改善。",
    "death_old": "上调缩短老年阶段预期存续时间；下调模拟慢病管理和医疗突破。",
    "child_years": "上调延长少年阶段、推迟进入劳动力；下调使人口更早进入成年队列。它是指数队列时间常数，不是法定成年年龄。",
    "adult_years": "上调延长成年劳动阶段并推迟老龄化；下调使人口更快进入老年队列。",
    "shortage_mortality": "上调表示食物或生命能源短缺更快转化为死亡；下调模拟应急医疗、配给和避难能力增强。",
    "crowding_mortality": "上调表示住房超员更易引发疾病和事故；下调模拟隔离、通风和社区医疗改善。",
    "epidemic": "从0上调可注入疫病、毒理或灾害的额外死亡风险；恢复为0表示外源冲击结束。",
    "migration": "上调增加每年的潜在地球移民需求；下调模拟火星吸引力下降、招募收缩或地球留人。实际到达仍受窗口、住房和运力约束。",
    "migration_female": "上调增加成年女性移民占比，下调增加成年男性占比；用于人口结构压力测试，不代表政策目标。",
    "emigration": "上调使低凝聚力下的返航意愿更强；下调模拟定居意愿、归属感或返航障碍增加。",
    "cohesion_target": "上调提高凝聚力长期目标，可模拟制度信任、公共服务和文化认同改善；下调模拟冲突和合法性危机。",
    "cohesion_speed": "上调使凝聚力更快靠近目标，也会更快吸收目标变化；下调表示社会惯性更强。",
    "cohesion_stress": "上调使资源短缺更快侵蚀凝聚力；下调模拟公平配给、沟通和互助提高社会韧性。",
    "research_share": "上调把更多名义产值预算配置给科研、减少同期限内其他可用财政资源；下调相反。应与建设支出占比联合比较。",
    "research_productivity": "上调提高同等科研投入带来的技术增长；下调模拟组织低效、封闭或研究失败。",
    "research_scale": "上调意味着科研达到半饱和所需资金更多、同额投入效果更弱；下调表示低成本研发和知识扩散更有效。",
    "tech_ceiling": "上调允许技术指数达到更高长期水平；下调模拟当前技术路线更早遇到瓶颈。它不是物理极限。",
    "knowledge_decay": "上调加快知识与组织能力流失；下调模拟教育、文档、人才留存和制度记忆改善。",
    "investment_share": "上调增加公共建设预算上限，可能加快扩张但挤占资金；下调抑制扩张并保留更多财政流动性。",
    "material_per_mw": "上调表示建设1MW能源容量需要更多原料；下调模拟轻量化、模块化和高功率密度。",
    "material_per_food": "上调表示农业设施更重、更复杂；下调模拟轻量温室、设备复用和集成化。",
    "material_per_mine": "上调提高工业/采集扩产的原料成本；下调模拟装备小型化与模块复用。",
    "material_per_home": "上调表示每人居住容量需要更多防压、防辐射结构；下调模拟洞穴利用、结构优化或共享空间。",
    "material_per_transport": "上调提高物流扩容的基础设施材料成本；下调模拟轻型车辆、线路复用和更高载荷率。",
    "build_price": "上调增加建设的名义资金成本；下调模拟施工生产率、供应链和标准化改善。价格指数会同步作用于实际支付。",
    "build_energy": "上调增加每吨建设材料的施工能耗；下调模拟预制、低温工艺和机械效率改善。",
    "build_labor": "上调增加单位建设量的劳动需求；下调模拟预制装配、施工机器人和设计标准化。",
    "build_delay": "上调延后新设施投产、放大需求预测误差；下调模拟模块化、审批简化和施工提速。",
    "reserve_food_years": "上调要求保留更长食物缓冲，提高断供韧性但减少可自由使用库存；下调提高短期使用空间但降低安全边际。",
    "reserve_material_years": "上调保留更多维护原料、抑制建设和出口；下调释放材料但提高维护断供风险。",
    "window": "默认固定为26个月近似值，输入范围上下限相同，通常不调；研究新轨道或推进方案时应先修改模型假设和证据。",
    "flight": "上调模拟更慢轨道或延误，增加在途时间；下调模拟快速转移。建议用4、7、12个月做离散对照。",
    "cargo_capacity": "上调增加每个窗口的地球货运上限；下调模拟运载不足、事故停飞或禁运。实际装载仍受财政和外汇约束。",
    "passenger_capacity": "上调增加每个窗口双向客运上限；下调模拟运力不足或安全限制。移民仍受住房和支付能力约束。",
    "delivery_success": "上调表示更高的期望成功交付比例；下调模拟发射、巡航、着陆或返航风险。模型使用期望值而非随机成败。",
    "import_food_fraction": "上调把固定进口运力更多分配给生物质，减少原料份额；下调则增加原料份额。应根据短缺结构联动调整。",
    "import_price": "上调提高进口货物的外汇和财政占用；下调模拟运载成本、规模经济或地球补贴改善。",
    "passenger_price": "上调降低财政可负担移民和居民可负担返航；下调模拟客运技术成熟与补贴。",
    "earth_grant": "上调增加财政存款和外部储备；下调模拟援助削减，设为0可模拟断援。它只增加资金，不直接生成火星实物。",
    "export_tech": "上调提高启动出口所需最低科技指数、推迟反哺；下调表示较低技术即可形成可交付高价值产品。",
    "export_population": "上调提高形成出口分工所需人口门槛；下调模拟小规模、高自动化出口产业。",
    "export_capacity": "上调增加每个窗口可发往地球的货物上限；下调模拟返航基础设施受限。仍受库存和运费约束。",
    "export_price": "上调增加成功到达后的出口收入；下调模拟地球需求、议价能力或产品价值下降。",
    "export_freight": "上调增加出口发射时支付的运费、抑制出口量；下调模拟返航运载成本下降。",
    "tax_rate": "上调增加工资税和销售税率、增强财政收入但减少居民与企业存款；下调相反。模型未含税率对行为的额外弹性。",
    "wage_share": "上调把更大产值份额支付为工资，提高居民收入并增加企业资金需求；下调保留更多企业存款。",
    "loan_rate": "上调增加企业利息负担和银行收入，代表紧缩与风险溢价；下调降低融资成本。未付利息当前不累积。",
    "bond_rate": "上调增加财政债券利息负担和银行收入；下调模拟财政信用改善或金融压抑。",
    "loan_amortization": "上调加快企业还本并收缩贷款和存款；下调延长贷款期限，但维持更久的债务敞口。",
    "default_rate": "上调加快贷款核销并侵蚀银行股本；下调模拟经营改善、担保和风险控制。",
    "capital_ratio": "上调提高银行资本约束、压低可新增贷款和购债空间；下调放松信贷，但增加杠杆和损失脆弱性。",
    "debt_limit": "上调允许公共债务相对产值达到更高水平；下调收紧财政融资。它是情景规则，不是普适安全阈值。",
    "money_velocity": "上调增加居民存款可支持的当期消费支付；下调模拟冻结、挤兑恐慌或支付系统失灵。",
    "inflation_speed": "上调使物价对短缺与流动性的反应更快；下调模拟价格管制、合同粘性或缓慢传导。",
    "price_food": "上调提高食物在基年产值中的权重；下调降低权重。它是核算价格，不能单独解释为真实市场价格预测。",
    "price_material": "上调提高原料产出和维护消耗在产值中的权重；下调降低权重。用于核算口径敏感性。",
    "price_energy": "上调提高生命用电在产值中的权重；下调降低权重。过高可能把低效率误计为高产值，应谨慎做敏感性分析。",
}


def _fmt(value: float) -> str:
    return f"{value:.8g}"


def _escape(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", " ")


def validate_coverage() -> None:
    grouped = [key for keys in GROUPS.values() for key in keys]
    if len(grouped) != len(set(grouped)):
        raise ValueError("参数分组存在重复项")
    missing_groups = set(PARAMETERS) - set(grouped)
    extra_groups = set(grouped) - set(PARAMETERS)
    missing_tuning = set(PARAMETERS) - set(TUNING)
    extra_tuning = set(TUNING) - set(PARAMETERS)
    if missing_groups or extra_groups or missing_tuning or extra_tuning:
        raise ValueError(
            "参数指南覆盖不完整："
            f"分组缺失={sorted(missing_groups)}，分组多余={sorted(extra_groups)}，"
            f"调参缺失={sorted(missing_tuning)}，调参多余={sorted(extra_tuning)}"
        )


def render_markdown() -> str:
    validate_coverage()
    lines = [
        "# 火星文明仿真系统：完整参数列表与调参指南",
        "",
        f"本文档直接依据 `mars_civilization/parameters.py` 生成，共 **{len(PARAMETERS)} 个可调参数**。参数初始值与代码默认值一致；允许范围来自 `Parameter.low` 和 `Parameter.high`。",
        "",
        "## 如何调参",
        "",
        "- 推荐先做单因素扫描：以初始值为中心测试 `-20%、-10%、初始值、+10%、+20%`，并始终限制在表中允许范围内。参数初始值为0时，可用允许范围的 `0%、5%、10%、25%` 作为起点。",
        "- 比例参数在配置文件中使用小数，例如 `research_share = 0.05` 表示5%；`1/年` 是年风险率或调整率；货币单位“百万MC”是模型中的虚构记账单位。",
        "- 单因素实验用于判断方向，多因素实验应采用配对情景或拉丁超立方/Sobol分析。能源、劳动、运输、库存与金融约束会产生非线性，表中的方向说明不保证终点指标严格单调。",
        "- `window` 的上下限相同，属于固定观测约束；若要研究不同发射窗口，应同步修改模型假设，而不是作为普通政策参数调整。",
        "",
        "参数覆盖可用以下命令校验：",
        "",
        "```powershell",
        "python run.py parameters",
        "```",
        "",
        "自定义情景可在 JSON 文件中只写需要覆盖的参数：",
        "",
        "```json",
        "{",
        "  \"research_share\": 0.05,",
        "  \"investment_share\": 0.22,",
        "  \"availability\": 0.90",
        "}",
        "```",
        "",
        "```powershell",
        "python run.py simulate --scenario baseline --params examples/policy.json --out outputs/my_policy.json",
        "```",
    ]
    index = 0
    for title, keys in GROUPS.items():
        lines.extend([
            "",
            f"## {title}",
            "",
            "|序号|参数键|参数意义|初始值|单位|允许范围|调参方式与方向|现实对应/解释|证据等级|",
            "|---:|---|---|---:|---|---|---|---|---|",
        ])
        for key in keys:
            index += 1
            p = PARAMETERS[key]
            bounds = f"{_fmt(p.low)} ～ {_fmt(p.high)}"
            lines.append(
                f"|{index}|`{key}`|{_escape(p.meaning)}|{_fmt(p.value)}|{_escape(p.unit)}|"
                f"{bounds}|{_escape(TUNING[key])}|{_escape(p.interpretation)}|{_escape(p.evidence)}|"
            )
    lines.extend([
        "",
        "## 调参顺序建议",
        "",
        "1. 先校准生命安全参数：`food_need`、`life_power`、三类死亡率、`shortage_mortality`。",
        "2. 再校准工程参数：生产率、单位能耗、劳动系数、材料系数、折旧与维护。",
        "3. 再校准运输边界：运力、航程、交付成功率、进口结构和价格。",
        "4. 最后调整行为与制度参数：生育、迁徙、凝聚力、科研、财政和银行参数。",
        "5. 每轮校准都同时检查食物/能源满足率、人口、库存、产值、银行股本和守恒审计；不要只优化末期人口或产值。",
        "",
        "## 证据等级",
        "",
        "- **O**：近似观测约束。当前仅发射窗口采用NASA资料约束。",
        "- **A**：参照具体任务案例。当前航程以Perseverance约七个月航行为参照，并非所有轨道方案的常数。",
        "- **H**：探索性假设，尚未用真实火星城市数据校准。允许范围是情景扫描边界，不是统计置信区间。",
        "",
        "资料 S2：[NASA JPL：Meet Perseverance](https://www.jpl.nasa.gov/edu/resources/teachable-moment/meet-perseverance-nasas-newest-mars-rover/)。",
    ])
    return "\n".join(lines) + "\n"


def main() -> None:
    output = Path(__file__).resolve().parent.parent / "docs" / "参数列表与调参指南.md"
    output.write_text(render_markdown(), encoding="utf-8")
    print(f"Generated {len(PARAMETERS)} parameters: {output}")


if __name__ == "__main__":
    main()
